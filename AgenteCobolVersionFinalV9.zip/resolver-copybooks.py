#!/usr/bin/env python3
"""
Resuelve el arbol completo de sentencias COPY de un programa COBOL.

Que hace, en palabras simples:
  1. Lee un programa COBOL y busca todas sus sentencias COPY.
  2. Por cada copybook encontrado, lo busca en las carpetas locales del repo.
  3. Si lo encuentra, lo abre y repite el proceso (los copybooks tambien
     pueden tener COPY dentro: eso es el "arbol anidado").
  4. Reporta cuales quedaron sin resolver.
  5. Opcionalmente descarga del host los que faltan, usando Zowe.

Para que sirve:
  - El agente necesita el arbol completo. Si falta un copybook, marca el
    hallazgo como INCOMPLETO en vez de suponer.
  - Si un copybook existe en el host pero NO en el repositorio clonado,
    eso es una desviacion: el fuente que compilas no es el que versionas.
    Es un riesgo de migracion por derecho propio.

Uso:
  resolver-copybooks.py <programa.cbl> [--repo RUTA] [--descargar] [--json]
  resolver-copybooks.py <carpeta>      [--repo RUTA] [--descargar]

Ejemplos:
  resolver-copybooks.py ../bancoavvillas/AV00/CICSLIB/AB/ABK110.CBL
  resolver-copybooks.py ../bancoavvillas --repo ../bancoavvillas
"""

import os
import re

# Carpeta donde vive este archivo (scripts/copybooks/), sin importar
# desde que directorio se haya invocado python. Todo lo que este script
# necesita ubicar en el paquete (config.env) se calcula a partir de esto,
# nunca con una ruta relativa al directorio de trabajo del usuario.
AQUI = os.path.dirname(os.path.abspath(__file__))
import sys
import json
import subprocess

# Reconoce las formas habituales de la sentencia COPY:
#   COPY NOMBRE.
#   COPY 'NOMBRE'.
#   COPY NOMBRE OF BIBLIOTECA.
#   COPY NOMBRE IN BIBLIOTECA.
RE_COPY = re.compile(
    r"""^\s{0,10}[^*/]?.{0,5}?\bCOPY\s+
        ['"]?(?P<nombre>[A-Z0-9$#@][A-Z0-9$#@\-_]{0,7})['"]?
        (?:\s+(?:OF|IN)\s+['"]?(?P<lib>[A-Z0-9$#@\-_.]+)['"]?)?
        \s*[.]?""",
    re.IGNORECASE | re.VERBOSE)

EXTENSIONES = ['', '.cpy', '.CPY', '.copy', '.COPY', '.cbl', '.CBL', '.cob', '.COB']

# Columna 7 marca comentario en COBOL de formato fijo
def es_comentario(linea):
    return len(linea) > 6 and linea[6] in ('*', '/')


def buscar_copys(ruta):
    """Devuelve la lista de nombres de copybook referenciados en un archivo."""
    encontrados = []
    try:
        with open(ruta, encoding='utf-8', errors='replace') as f:
            for linea in f:
                if es_comentario(linea):
                    continue
                m = RE_COPY.search(linea)
                if m:
                    encontrados.append(m.group('nombre').upper())
    except OSError:
        pass
    return encontrados


def indexar_repo(raiz):
    """
    Recorre el repositorio una sola vez y arma un indice
    nombre-en-mayusculas -> ruta del archivo.
    Asi la busqueda posterior es instantanea.
    """
    indice = {}
    for base, dirs, archivos in os.walk(raiz):
        dirs[:] = [d for d in dirs if d not in ('.git', 'node_modules', '.c4z')]
        for a in archivos:
            stem, ext = os.path.splitext(a)
            if ext.lower() in ('.pdf', '.png', '.jpg', '.zip', '.class', '.o'):
                continue
            clave = stem.upper()
            if clave not in indice:
                indice[clave] = os.path.join(base, a)
    return indice


def descargar_del_host(nombre, pds_lista, destino, perfil=None):
    """Intenta traer el miembro del host con Zowe. Devuelve la ruta o None."""
    os.makedirs(destino, exist_ok=True)
    for pds in pds_lista:
        salida = os.path.join(destino, nombre + '.cpy')
        cmd = ['zowe', 'zos-files', 'download', 'data-set',
               f'{pds}({nombre})', '-f', salida]
        if perfil:
            cmd += ['--zosmf-profile', perfil]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
        except (OSError, subprocess.TimeoutExpired):
            continue
        if r.returncode == 0 and os.path.isfile(salida) and os.path.getsize(salida) > 0:
            return salida
    return None


def resolver(programa, indice, pds_lista, destino, perfil, descargar, visitados=None):
    """
    Recorre el arbol de COPY en profundidad.
    Devuelve un diccionario con el arbol y las listas de resueltos y faltantes.
    """
    if visitados is None:
        visitados = set()

    nodo = {'archivo': programa, 'hijos': [], 'faltantes': []}

    for nombre in buscar_copys(programa):
        if nombre in visitados:
            nodo['hijos'].append({'nombre': nombre, 'estado': 'ya visitado'})
            continue
        visitados.add(nombre)

        ruta = indice.get(nombre)
        origen = 'repositorio'

        if ruta is None and descargar and pds_lista:
            ruta = descargar_del_host(nombre, pds_lista, destino, perfil)
            if ruta:
                origen = 'host (NO esta en el repositorio)'
                indice[nombre] = ruta

        if ruta is None:
            nodo['faltantes'].append(nombre)
            nodo['hijos'].append({'nombre': nombre, 'estado': 'NO ENCONTRADO'})
            continue

        sub = resolver(ruta, indice, pds_lista, destino, perfil, descargar, visitados)
        nodo['hijos'].append({
            'nombre': nombre,
            'estado': 'resuelto',
            'origen': origen,
            'ruta': ruta,
            'detalle': sub,
        })
        nodo['faltantes'].extend(sub['faltantes'])

    return nodo


def aplanar(nodo, nivel=0, acc=None):
    if acc is None:
        acc = []
    for h in nodo['hijos']:
        acc.append((nivel, h))
        if h.get('detalle'):
            aplanar(h['detalle'], nivel + 1, acc)
    return acc


def imprimir(nodo):
    print('=' * 70)
    print(f"Programa: {nodo['archivo']}")
    print('=' * 70)
    print()

    plano = aplanar(nodo)
    if not plano:
        print('  El programa no referencia ningun copybook.')
        print()
        return

    print('ARBOL DE COPY')
    print()
    for nivel, h in plano:
        sangria = '  ' + '   ' * nivel
        if h['estado'] == 'resuelto':
            marca = 'OK ' if h.get('origen') == 'repositorio' else 'HOST'
            print(f"{sangria}{marca} {h['nombre']}")
        elif h['estado'] == 'NO ENCONTRADO':
            print(f"{sangria}!!  {h['nombre']}   <-- NO ENCONTRADO")
        else:
            print(f"{sangria}..  {h['nombre']}   (ya procesado)")
    print()

    del_host = [h for _, h in plano
                if h['estado'] == 'resuelto' and h.get('origen', '').startswith('host')]
    faltantes = sorted(set(nodo['faltantes']))
    resueltos = [h for _, h in plano if h['estado'] == 'resuelto']

    print('RESUMEN')
    print(f"  Copybooks resueltos : {len(resueltos)}")
    print(f"  Desde el repositorio: {len(resueltos) - len(del_host)}")
    print(f"  Solo desde el host  : {len(del_host)}")
    print(f"  Sin resolver        : {len(faltantes)}")
    print()

    if del_host:
        print('DESVIACION REPOSITORIO / HOST')
        print('  Estos copybooks existen en el mainframe pero NO en el repositorio')
        print('  clonado. El fuente que se compila no es igual al que se versiona.')
        print('  Reportar al lider tecnico: es un riesgo de migracion independiente')
        print('  del catalogo de reglas.')
        print()
        for h in del_host:
            print(f"    - {h['nombre']}")
        print()

    if faltantes:
        print('SIN RESOLVER')
        print('  El agente marcara como INCOMPLETO los hallazgos que dependan')
        print('  de estos copybooks. Conseguirlos antes de analizar.')
        print()
        for n in faltantes:
            print(f"    - {n}")
        print()


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    if not args:
        print(__doc__)
        sys.exit(1)

    objetivo = args[0]

    repo = None
    for i, a in enumerate(sys.argv):
        if a == '--repo' and i + 1 < len(sys.argv):
            repo = sys.argv[i + 1]
    if repo is None:
        repo = objetivo if os.path.isdir(objetivo) else os.path.dirname(objetivo) or '.'

    descargar = '--descargar' in sys.argv
    pds_lista = []
    perfil = None
    destino = 'entradas/copybooks-host'

    # AQUI = carpeta scripts/copybooks/ donde vive este archivo.
    # Se sube un nivel y se entra a zowe/ para ubicar config.env
    # SIN IMPORTAR desde que carpeta se haya invocado python.
    cfg = os.path.join(AQUI, '..', 'zowe', 'config.env')
    if os.path.isfile(cfg):
        with open(cfg, encoding='utf-8') as f:
            for ln in f:
                if ln.startswith('COPYBOOK_PDS='):
                    valor = ln.split('=', 1)[1].strip().strip('"').strip("'")
                    pds_lista = [x.strip() for x in valor.split(',') if x.strip()]
                if ln.startswith('ZOWE_PROFILE='):
                    perfil = ln.split('=', 1)[1].strip().strip('"').strip("'") or None

    if descargar and not pds_lista:
        print(f'Se pidio --descargar pero no se pudo leer COPYBOOK_PDS desde:')
        print(f'  {os.path.abspath(cfg)}')
        if not os.path.isfile(cfg):
            print('  (el archivo no existe en esa ruta)')
        else:
            print('  (el archivo existe pero no tiene la variable COPYBOOK_PDS)')
        sys.exit(1)

    print(f'Indexando {repo} ...')
    indice = indexar_repo(repo)
    print(f'  {len(indice)} archivos indexados')
    print()

    programas = []
    if os.path.isdir(objetivo):
        for base, dirs, archivos in os.walk(objetivo):
            dirs[:] = [d for d in dirs if d not in ('.git', 'node_modules', '.c4z')]
            for a in archivos:
                if os.path.splitext(a)[1].lower() in ('.cbl', '.cob', '.cobol'):
                    programas.append(os.path.join(base, a))
    else:
        programas = [objetivo]

    resultados = []
    for p in programas:
        r = resolver(p, indice, pds_lista, destino, perfil, descargar)
        resultados.append(r)
        if '--json' not in sys.argv:
            imprimir(r)

    if '--json' in sys.argv:
        print(json.dumps(resultados, indent=2, ensure_ascii=False))
    elif len(programas) > 1:
        total_falt = sum(len(set(r['faltantes'])) for r in resultados)
        print('=' * 70)
        print(f'TOTAL: {len(programas)} programas, {total_falt} referencias sin resolver')
        print('=' * 70)


if __name__ == '__main__':
    main()
