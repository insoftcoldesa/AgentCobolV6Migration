# Guía de uso — Decisiones de diseño

Este documento explica **por qué** el agente está construido así. No es necesario leerlo para operarlo: para eso están `PASO-A-PASO.md` e `INSTRUCTIVO.md`. Sirve para entender los límites del montaje y para decidir bien cuando aparezca una situación que los documentos no cubren.

---

> **Actualizado en la versión 2.0.** La premisa original de este documento era que el compilador tenía las verificaciones apagadas. Al leer la configuración real resultó lo contrario: `INITCHECK(STRICT)`, `NUMCHECK` con abend, `SSRANGE` y `DIAGTRUNC` están activos. Las secciones siguientes reflejan esa corrección.

## El problema de fondo

En una migración de COBOL V4.2 a 6.4 los errores se reparten en dos grupos muy distintos.

**Los ruidosos.** El programa no compila, o abendea en pruebas. Duelen, pero se ven. El ciclo normal de compilar hasta llegar a código de retorno 0 los encuentra todos.

**Los que llegan sin señal.** El programa compila, pasa las pruebas, se promueve, y en producción devuelve un número distinto al que devolvía con el compilador anterior.

El agente existe por el segundo grupo.

---

## Por qué siguen existiendo, con las verificaciones activas

La instalación compila con `INITCHECK(STRICT)`, `NUMCHECK(ZON(ALPHNUM,STRICTREDEF),PAC,BIN(TRUNCBIN),ABD)`, `SSRANGE` y `DIAGTRUNC`. Es una buena configuración, y corresponde a la fase 1 de la estrategia del banco. Muchos defectos que este catálogo describe **abendean en pruebas**, de forma ruidosa e inconfundible.

Quedan dos huecos, y son los que justifican el agente.

**La cobertura de las pruebas.** `NUMCHECK` verifica el dato cuando el programa lo toca. Si los datos de prueba no recorren la rama donde está el `REDEFINES` mal inicializado, no hay nada que verificar. La condición pasa limpia y nadie se entera.

**La fase 2.** La estrategia indica recompilar con `NONUMCHECK`, `NOSSRANGE` y `NOPARMCHECK` para calidad y producción, buscando rendimiento. En ese momento desaparece toda la red. Lo que no se encontró en fase 1 ya no va a avisar nunca.

Por eso cada regla del catálogo lleva dos severidades, y el veredicto se decide por la de fase 2.

---

## Por qué el agente actúa antes de compilar

Un abend en pruebas te dice que hay un problema cuando ya invertiste en preparar datos, someter el job y diagnosticar un dump. El agente señala la misma condición leyendo el fuente, antes de someter nada.

No reemplaza la verificación en ejecución: la anticipa, y cubre lo que ella no alcanza.

---

## Por qué el análisis es sobre fuente y no sobre el listado

Podría parecer que lo natural es leer el listado de compilación y trabajar sobre sus mensajes. Es al revés.

> El listado dice lo que el compilador **sí dijo**. El valor del agente está en lo que el compilador **no dijo**.

Con las verificaciones apagadas, las reglas de mayor severidad no producen ningún mensaje. Un análisis basado solo en el listado las perdería todas. Por eso el fuente y los copybooks son obligatorios, y el listado es complemento útil pero no indispensable.

---

## Por qué se trabaja sobre el repositorio clonado

Una versión anterior de este montaje pedía copiar los fuentes a una carpeta de entrada. Eso era una solución a un problema que ya no existe: en su momento no había acceso directo a los fuentes.

Con el repositorio clonado, copiar archivos introduce dos riesgos y ningún beneficio: se puede analizar una copia desactualizada, y se pierde la correspondencia exacta entre lo analizado y lo versionado.

El diseño actual abre dos carpetas en el mismo workspace. El agente lee del clon. Lo que está en Git es lo que se analiza.

---

## Por qué Z Open Editor y no COBOL Language Support

Las dos extensiones resuelven copybooks desde bibliotecas del mainframe. La diferencia está en otro lado.

| Criterio | Z Open Editor | COBOL Language Support |
|---|---|---|
| Lenguajes | COBOL, PL/I, HLASM, REXX, **JCL** | Solo COBOL |
| Dialecto | Enterprise COBOL de IBM | Implementación propia |
| Configuración | `zapp.yaml`, versionable | Ajustes del workspace |

Pesaron tres cosas. Hay JCL en el alcance, y Broadcom no lo soporta. El destino de la migración es el compilador de IBM, y el catálogo de reglas está construido sobre semántica de IBM. Y `zapp.yaml` viaja en el repositorio de fuentes, de modo que la resolución de copybooks se configura una vez para todo el equipo.

Las dos no pueden convivir en el mismo workspace: entran en conflicto y ninguna funciona.

---

## Por qué quedó una sola sonda

El kit original tenía cinco. Iban a averiguar, por observación, cosas que normalmente se le preguntan al administrador de sistemas.

Resultó que casi todo estaba disponible sin compilar nada: el spool de una compilación cualquiera trae el nivel del compilador y el procedimiento expandido, y de ahí se llega al archivo de opciones de la instalación. Cuatro sondas quedaron sin objeto.

Sobrevivió `ZZB04`, la única que prueba **comportamiento del lenguaje** y no configuración. Ningún archivo dice qué hace `INITIALIZE` sobre un `REDEFINES` en este sistema: hay que ejecutarlo.

La lección es reutilizable: antes de diseñar un experimento, vale la pena mirar qué información ya está disponible en los artefactos que el sistema produce a diario.

---

## Por qué la triple evidencia

Cada hallazgo exige la línea del fuente, el identificador de regla y la sección del manual de IBM. Sin las tres, se degrada a observación y no cuenta para el cierre.

La razón es de confianza. Un agente que ocasionalmente inventa un número de mensaje o una sección de manual destruye su propia utilidad: el equipo deja de creerle y vuelve a revisar todo a mano. Es preferible un informe que declara explícitamente lo que no pudo verificar.

De ahí también las marcas `INCOMPLETO`, `SIN-RESPALDO` y `NO EVALUABLE`. No son fallas del agente: son el agente diciendo qué le falta.

---

## Por qué importa la desviación repositorio / mainframe

El resolvedor de copybooks distingue los que encuentra en el clon de los que solo aparecen en el mainframe.

Esa diferencia es un hallazgo por derecho propio, independiente del catálogo de reglas. Si un copybook existe en el host y no en Git, el programa que se compila no es igual al que se versiona. Cualquier análisis sobre el repositorio estará incompleto, y cualquier corrección hecha sobre Git puede no llegar a producción.

Vale la pena reportarlo siempre, aunque no tenga relación con la migración.

---

## Qué no puede resolver este montaje

Conviene decirlo explícitamente ante el negocio y ante el cierre de cada entregable.

**No confirma el inventario de correcciones del compilador.** Se conoce el nivel de servicio `P240621`, no qué PTF están aplicados. Alcanza para decidir sobre código; no alcanza para un reporte de cumplimiento.

**No cambia las opciones de compilación.** Los hallazgos de la familia `OPT` son recomendaciones, con una diferencia importante: varios se respaldan en la estrategia de la propia Gerencia de Desarrollo, así que no son opinión externa sino desviación frente al estándar interno.

**No mide la cobertura de las pruebas.** El agente señala que una condición está en una rama condicional, pero no puede saber si los datos de prueba la recorren. Esa verificación es humana.

**No conoce las opciones de fase 2.** Están sin confirmar. Mientras tanto, la severidad de fase 2 se calcula suponiendo que se apagan `NUMCHECK`, `SSRANGE` y `PARMCHECK`, como indica la estrategia.

**No sustituye el criterio humano.** El paso de validación del piloto no es una formalidad: es lo que calibra el catálogo contra la realidad del código de este banco.

Declarar estos límites no es un descargo. Un riesgo detectado y no verificable por falta de permisos es un **riesgo transferido**, que es la posición correcta del equipo de desarrollo. Callarlo lo convertiría en un riesgo ignorado.
