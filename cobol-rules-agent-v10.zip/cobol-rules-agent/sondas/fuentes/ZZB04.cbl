       IDENTIFICATION DIVISION.
       PROGRAM-ID. ZZB04.
      *----------------------------------------------------------------
      * ZZB04 - Regla RDF-01
      * Demuestra que INITIALIZE no alcanza las vistas REDEFINES
      *
      * Esperado en SYSOUT:
      *   ZZB04 RESULTADO: NO ES NUMERICO
      *
      * Con NUMCHECK(ZON(...,STRICTREDEF),ABD) activo puede abendar
      * antes del DISPLAY. Ese resultado tambien es valido: anotar
      * cual de los dos ocurrio.
      *
      * Compilar:  C62BATD 'DESA.AV00.BATCHLIB(ZZB04)'
      * Borrar el miembro al terminar.
      *----------------------------------------------------------------
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-GRUPO.
           05  WS-TEXTO        PIC X(4).
           05  WS-NUMERO REDEFINES WS-TEXTO PIC 9(4).
       PROCEDURE DIVISION.
           INITIALIZE WS-GRUPO
           DISPLAY 'ZZB04 TEXTO  : [' WS-TEXTO ']'
           DISPLAY 'ZZB04 NUMERO : [' WS-NUMERO ']'
           IF WS-NUMERO IS NUMERIC
               DISPLAY 'ZZB04 RESULTADO: ES NUMERICO'
           ELSE
               DISPLAY 'ZZB04 RESULTADO: NO ES NUMERICO'
           END-IF
           GOBACK.
