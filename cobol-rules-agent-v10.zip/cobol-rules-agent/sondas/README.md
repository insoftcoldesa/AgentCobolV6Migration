# Sonda restante

El kit original tenía cinco sondas. **Cuatro ya no hacen falta.**

La configuración real del entorno quedó verificada leyendo el spool de una compilación y el archivo de opciones de la instalación. Eso respondió lo que las sondas iban a averiguar, sin compilar nada. Ver `entorno/CONFIGURACION-ACTUAL.md`.

| Sonda | Averiguaba | Resuelta por |
|---|---|---|
| SONDA01 | Si se pueden sobrescribir opciones | `PARM='OPTFILE'` en el procedimiento |
| SONDA02 | Falso positivo de `LINKAGE` | Solo aplicaba para calibrar `INITCHECK` |
| SONDA03 / 03B | Modo de `INITCHECK` | Confirmado `STRICT` en `CBLO62BD` |
| SONDA05 | Nivel y opciones del compilador | Sección 2 de `CONFIGURACION-ACTUAL.md` |

---

## SONDA04 — sigue vigente

Es la única que prueba **comportamiento del lenguaje**, no configuración. Ninguna lectura de archivos la reemplaza: hay que ejecutarla.

Demuestra la regla `RDF-01`: que `INITIALIZE` sobre un grupo **no alcanza** a los campos definidos con `REDEFINES`.

### Por qué vale la pena

Convierte la regla crítica central del catálogo en evidencia propia del equipo, generada sobre este mismo sistema. Ante el negocio y ante el GATE, "lo probamos aquí" pesa distinto que "lo dice el manual".

Cuesta una compilación y una ejecución.

### Restricción de nomenclatura

El comando `C62BATD` valida el nombre antes de compilar: el **tercer carácter** del miembro debe ser `I`, `B`, `C`, `S` o un dígito. `SONDA04` tiene `N` y sería rechazado con `*** EL NOMBRE DEL OBJETO NO CUMPLE ESTANDARES ***`.

Por eso el fuente se llama **`ZZB04`**. El prefijo `ZZ` además lo deja al final del listado del PDS, fácil de identificar y borrar.

### Dónde ponerlo

El comando copia desde `DESA.AV00.BATCHLIB` hacia `DESA.AV01.BATCHLIB`. No lee bibliotecas personales, así que el miembro tiene que pasar por la biblioteca compartida del área.

Son veinte líneas y se borra al terminar, pero conviene avisar al equipo antes.

### Ejecutar

```
C62BATD 'DESA.AV00.BATCHLIB(ZZB04)'
```

Luego ejecutar el módulo y revisar el `SYSOUT`.

### Resultado esperado

```
ZZB04 TEXTO  : [    ]
ZZB04 NUMERO : [    ]
ZZB04 RESULTADO: NO ES NUMERICO
```

`NO ES NUMERICO` confirma la regla: `INITIALIZE` dejó el grupo en espacios y la vista numérica quedó inválida.

### Variante interesante

Con `NUMCHECK(ZON(ALPHNUM,STRICTREDEF),...,ABD)` activo en la instalación, es posible que el programa **abende** antes de llegar al `DISPLAY`, en cuanto toque la vista numérica.

Ese resultado es igual de válido y de hecho más contundente: demuestra que la verificación en ejecución sí atrapa el caso en fase 1. Anota cuál de los dos ocurrió, porque cambia cómo se interpreta toda la familia `RDF`.

### Registrar

Anota el resultado en `entorno/CONFIGURACION-ACTUAL.md`, sección 5, indicando si terminó con salida normal o con abend.

### Limpiar

Borra `ZZB04` de `DESA.AV00.BATCHLIB` y de `DESA.AV01.BATCHLIB`, y el módulo de la LOADLIB.
