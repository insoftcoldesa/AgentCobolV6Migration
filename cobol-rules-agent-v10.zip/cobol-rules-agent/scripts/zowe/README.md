# Scripts de Zowe

Zowe CLI es opcional en este montaje. Sirve para automatizar, no es requisito.

## Qué necesita Zowe y qué no

| Tarea | ¿Necesita Zowe CLI? |
|---|---|
| Analizar programas con el agente | No. Lee del repositorio clonado |
| Resolver el árbol de copybooks local | No |
| Descargar copybooks que faltan en el clon | Sí, o hacerlo a mano con Zowe Explorer |
| Analizar un listado de compilación | No. `parse-listado.py` funciona sobre el archivo |
| Bajar el listado del spool | Zowe Explorer basta, desde la interfaz |

Si Zowe CLI no se puede instalar, **Zowe Explorer cubre lo esencial** desde VS Code: navegar bibliotecas, abrir miembros, someter trabajos y ver su salida.

---

## configurar-zowe.sh

Configura la conexión y el certificado. Ver etapa 2 del `INSTRUCTIVO`.

El certificado de z/OSMF suele ser autofirmado y el navegador lo rechaza. Zowe tiene su propio control, así que **no hace falta que el navegador funcione**.

## verificar-entorno.sh

Diagnóstico completo del montaje: herramientas, manuales, configuración y conexión. Reporta `[OK]`, `[AVISO]` o `[FALLA]` y dice qué falta.

Es el primer comando a correr cuando algo no funciona.

## parse-listado.py

Lee un listado de compilación y extrae el nivel del compilador, las opciones en efecto y los mensajes `IGY`.

```bash
python3 scripts/zowe/parse-listado.py entradas/listados/PGMXXXX.lst
python3 scripts/zowe/parse-listado.py entradas/listados/PGMXXXX.lst --json
```

Es la herramienta con la que se obtuvo buena parte de `entorno/CONFIGURACION-ACTUAL.md`.

**Un detalle propio de esta instalación:** el paso de compilación usa `PARM='OPTFILE'`, así que las opciones no aparecen en el JCL sino en el archivo apuntado por el DD `SYSOPTF`. El listado sí imprime el bloque de opciones en efecto, que es lo que el script busca.

---

## Cuidado con la codificación

Al bajar cualquier cosa del mainframe, la conversión EBCDIC a ASCII debe usar la página de código real del sitio. Si sale mal, los acentos de los comentarios se corrompen y el agente termina citando basura como si fuera evidencia.

Verifícalo en la primera descarga: abre el archivo y busca una `ñ` o una vocal acentuada en algún comentario.

---

## Seguridad

`config.env` y `zowe.config.user.json` están en `.gitignore`. **Las credenciales del mainframe nunca deben llegar al repositorio.**

Ningún script de este paquete escribe hacia bibliotecas de promoción ni de producción. Solo lectura, y compilación en espacio propio.
