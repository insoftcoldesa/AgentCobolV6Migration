#!/usr/bin/env bash
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$ROOT"

ok=0
fallo=0
aviso=0

titulo() {
  echo ""
  echo "== $1"
}

bien()  { echo "   [OK]    $1"; ok=$((ok+1)); }
mal()   { echo "   [FALLA] $1"; fallo=$((fallo+1)); }
warn()  { echo "   [AVISO] $1"; aviso=$((aviso+1)); }

echo "==================================================="
echo " Verificacion del entorno"
echo " Proyecto: $ROOT"
echo "==================================================="

titulo "Herramientas locales"
command -v python3 >/dev/null 2>&1 && bien "python3 instalado" || mal "falta python3"
command -v pdftotext >/dev/null 2>&1 && bien "pdftotext instalado" || warn "falta pdftotext (brew install poppler)"
command -v zowe >/dev/null 2>&1 && bien "zowe instalado" || mal "falta zowe CLI"
command -v git >/dev/null 2>&1 && bien "git instalado" || warn "falta git"

titulo "Corpus documental"
n64=$(ls -1 docs-ibm/6.4/txt/*.txt 2>/dev/null | wc -l | tr -d ' ')
n42=$(ls -1 docs-ibm/origen/txt/*.txt 2>/dev/null | wc -l | tr -d ' ')
[ "$n64" = "6" ] && bien "manuales 6.4 convertidos: $n64 de 6" || mal "manuales 6.4: $n64 de 6"
[ "$n42" = "3" ] && bien "manuales V4.2 convertidos: $n42 de 3" || warn "manuales V4.2: $n42 de 3 (MIG-07 quedara NO EVALUABLE)"

titulo "Perfil del agente"
[ -f ".github/agents/cobol-rules-validator.agent.md" ] \
  && bien "perfil del agente presente" \
  || mal "falta .github/agents/cobol-rules-validator.agent.md"
[ -f "reglas/catalogo-reglas.md" ] \
  && bien "catalogo de reglas presente" \
  || mal "falta reglas/catalogo-reglas.md"

titulo "Configuracion"
if [ -f "scripts/zowe/config.env" ]; then
  bien "config.env existe"
  . scripts/zowe/config.env
  if [ -n "${REPO_FUENTES:-}" ] && [ -d "${REPO_FUENTES}" ]; then
    n=$(find "$REPO_FUENTES" -type f \( -name '*.cbl' -o -name '*.CBL' \) 2>/dev/null | wc -l | tr -d ' ')
    bien "repositorio de fuentes accesible: $REPO_FUENTES ($n programas)"
  else
    mal "REPO_FUENTES no apunta a una carpeta valida: ${REPO_FUENTES:-vacio}"
  fi
  [ -n "${COPYBOOK_PDS:-}" ] && bien "COPYBOOK_PDS definido" || warn "COPYBOOK_PDS vacio (no se podra descargar del host)"
  [ -n "${SONDA_PDS:-}" ] && bien "SONDA_PDS definido" || warn "SONDA_PDS vacio (las sondas no se podran ejecutar)"
else
  mal "falta scripts/zowe/config.env (copiar de config.env.ejemplo)"
fi

titulo "Conexion al mainframe"
if command -v zowe >/dev/null 2>&1; then
  if zowe zosmf check status >/dev/null 2>&1; then
    bien "z/OSMF responde"
  else
    mal "z/OSMF no responde. Ejecutar: ./scripts/zowe/configurar-zowe.sh"
  fi
else
  mal "zowe no instalado, no se puede verificar"
fi

titulo "Configuracion del entorno"
if [ -f "entorno/CONFIGURACION-ACTUAL.md" ]; then
  bien "entorno/CONFIGURACION-ACTUAL.md existe"
  grep -q "PENDIENTE" entorno/CONFIGURACION-ACTUAL.md \
    && warn "hay puntos PENDIENTE por verificar (ver seccion 6)" \
    || bien "sin pendientes marcados"
else
  mal "falta entorno/CONFIGURACION-ACTUAL.md"
fi

echo ""
echo "==================================================="
echo " Correcto: $ok    Avisos: $aviso    Fallas: $fallo"
echo "==================================================="
echo ""

if [ "$fallo" -gt 0 ]; then
  echo "Hay fallas que impiden operar. Revisar arriba."
  exit 1
fi
if [ "$aviso" -gt 0 ]; then
  echo "Se puede trabajar, pero algunas familias de reglas quedaran limitadas."
  exit 0
fi
echo "Entorno completo. Listo para analizar."
