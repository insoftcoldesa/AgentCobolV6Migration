#!/usr/bin/env python3
"""
Parsea el SYSPRINT de una compilacion Enterprise COBOL y extrae:
  - version y nivel de servicio del compilador
  - bloque de opciones en efecto
  - mensajes IGY emitidos
  - codigo de retorno del paso de compilacion

Uso:
  parse-listado.py <archivo.lst> [--json]

Es deliberadamente tolerante: si no reconoce una seccion, lo dice
en vez de inventarla. Todo lo dudoso se marca para revision humana.
"""

import sys
import re
import json

RE_MENSAJE = re.compile(r'\b(IGY[A-Z]{0,2}\d{4})-([IWESU])\b')
RE_NIVEL = re.compile(r'\b(\d+\.\d+\.\d+)\s+(P\d{6})\b')
RE_VERSION_ALT = re.compile(r'Enterprise COBOL for z/OS\s+([\d.]+)', re.I)

OPCIONES_INTERES = [
    'INITCHECK', 'NUMCHECK', 'RULES', 'PARMCHECK', 'SSRANGE',
    'DIAGTRUNC', 'INVDATA', 'NUMPROC', 'ZONEDATA', 'OPT',
    'ARCH', 'TUNE', 'RENT', 'SIZE', 'TEST', 'ADATA',
    'LIST', 'MAP', 'XREF', 'SOURCE', 'DYNAM', 'TRUNC',
]

SEVERIDAD = {
    'I': 'Informativo',
    'W': 'Advertencia',
    'E': 'Error',
    'S': 'Severo',
    'U': 'Irrecuperable',
}


def leer(ruta):
    for cp in ('utf-8', 'latin-1', 'cp1252'):
        try:
            with open(ruta, encoding=cp) as f:
                return f.read().splitlines()
        except UnicodeDecodeError:
            continue
    with open(ruta, encoding='utf-8', errors='replace') as f:
        return f.read().splitlines()


def nivel_compilador(lineas):
    for ln in lineas[:400]:
        m = RE_NIVEL.search(ln)
        if m:
            return {'version': m.group(1), 'ptf': m.group(2), 'linea': ln.strip()}
    for ln in lineas[:400]:
        m = RE_VERSION_ALT.search(ln)
        if m:
            return {'version': m.group(1), 'ptf': None, 'linea': ln.strip()}
    return None


def opciones(lineas):
    encontradas = {}
    crudo = []
    dentro = False
    for i, ln in enumerate(lineas[:1200]):
        alto = ln.upper()
        if 'OPTIONS IN EFFECT' in alto or 'PROCESS/CBL' in alto:
            dentro = True
        if dentro:
            crudo.append(ln.rstrip())
            if len(crudo) > 120:
                dentro = False
        for op in OPCIONES_INTERES:
            patron = r'\b(NO)?' + op + r'\b(\([^)]*\))?'
            m = re.search(patron, alto)
            if m and op not in encontradas:
                encontradas[op] = m.group(0)
    return encontradas, crudo


def mensajes(lineas):
    salida = []
    vistos = set()
    for i, ln in enumerate(lineas):
        m = RE_MENSAJE.search(ln)
        if not m:
            continue
        clave = (m.group(1), i)
        if clave in vistos:
            continue
        vistos.add(clave)
        salida.append({
            'id': m.group(1),
            'severidad': m.group(2),
            'severidad_texto': SEVERIDAD.get(m.group(2), '?'),
            'linea_listado': i + 1,
            'texto': ln.strip()[:300],
        })
    return salida


def codigo_retorno(lineas):
    for ln in lineas:
        m = re.search(r'RETURN CODE\s+(\d+)', ln.upper())
        if m:
            return int(m.group(1))
        m = re.search(r'\bCOND CODE\s+(\d+)', ln.upper())
        if m:
            return int(m.group(1))
        m = re.search(r'HIGHEST SEVERITY.*?(\d+)', ln.upper())
        if m:
            return int(m.group(1))
    return None


def analizar(ruta):
    lineas = leer(ruta)
    ops, crudo = opciones(lineas)
    msgs = mensajes(lineas)
    return {
        'archivo': ruta,
        'lineas_totales': len(lineas),
        'nivel': nivel_compilador(lineas),
        'opciones': ops,
        'opciones_crudo': crudo,
        'mensajes': msgs,
        'codigo_retorno': codigo_retorno(lineas),
        'conteo_severidad': {
            s: sum(1 for m in msgs if m['severidad'] == s)
            for s in 'IWESU'
        },
    }


def imprimir(r):
    print('=' * 68)
    print(f"Listado: {r['archivo']}  ({r['lineas_totales']} lineas)")
    print('=' * 68)

    print('\n--- NIVEL DEL COMPILADOR ---')
    if r['nivel']:
        n = r['nivel']
        print(f"  Version: {n['version']}   PTF: {n['ptf'] or 'no detectado'}")
        print(f"  Linea:   {n['linea']}")
    else:
        print('  NO DETECTADO. Revisar manualmente el encabezado del listado.')

    print('\n--- OPCIONES DE INTERES ---')
    if r['opciones']:
        for k in sorted(r['opciones']):
            print(f"  {k:<12} -> {r['opciones'][k]}")
    else:
        print('  NO DETECTADAS. Revisar el bloque OPTIONS IN EFFECT a mano.')

    print('\n--- MENSAJES ---')
    if r['mensajes']:
        for m in r['mensajes']:
            print(f"  [{m['severidad']}] {m['id']}  linea {m['linea_listado']}")
            print(f"       {m['texto']}")
    else:
        print('  Ninguno.')

    c = r['conteo_severidad']
    print(f"\n  Resumen: I={c['I']}  W={c['W']}  E={c['E']}  S={c['S']}  U={c['U']}")
    print(f"  Codigo de retorno: {r['codigo_retorno'] if r['codigo_retorno'] is not None else 'no detectado'}")
    print()


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    if not args:
        print(__doc__)
        sys.exit(1)
    r = analizar(args[0])
    if '--json' in sys.argv:
        r.pop('opciones_crudo', None)
        print(json.dumps(r, indent=2, ensure_ascii=False))
    else:
        imprimir(r)


if __name__ == '__main__':
    main()
