#!/usr/bin/env bash
set -uo pipefail

echo "==================================================="
echo " Configuracion de Zowe CLI"
echo "==================================================="
echo ""
echo "Este script configura la conexion al mainframe."
echo "Necesitas tener a mano:"
echo "  - direccion y puerto de z/OSMF (ejemplo: 10.10.1.85 puerto 1443)"
echo "  - tu usuario y contrasena de TSO"
echo ""

if ! command -v zowe >/dev/null 2>&1; then
  echo "Zowe CLI no esta instalado."
  echo "Instalar con: npm install -g @zowe/cli"
  exit 1
fi

echo "Version de Zowe:"
zowe --version
echo ""

if [ ! -f "$HOME/.zowe/zowe.config.json" ]; then
  echo ">> No existe configuracion global. Creandola."
  zowe config init --global-config
  echo ""
else
  echo ">> Configuracion global encontrada en ~/.zowe/zowe.config.json"
  echo ""
fi

echo "==================================================="
echo " Certificado"
echo "==================================================="
echo ""
echo "z/OSMF suele usar un certificado autofirmado por el propio"
echo "mainframe. Los navegadores y Zowe lo rechazan por defecto."
echo ""
echo "Al desactivar la validacion aceptas que no hay garantia"
echo "criptografica de que el servidor sea el que dice ser."
echo "Contra una direccion IP interna y fija el riesgo es bajo,"
echo "y es la practica habitual con z/OSMF autofirmado."
echo ""
printf "Desactivar la validacion del certificado? [s/N] "
read -r respuesta

if [ "$respuesta" = "s" ] || [ "$respuesta" = "S" ]; then
  zowe config set "profiles.zosmf.properties.rejectUnauthorized" false --global-config 2>/dev/null
  zowe config set "profiles.base.properties.rejectUnauthorized" false --global-config 2>/dev/null
  echo ""
  echo ">> Desactivada."
  echo ""
  echo "Verificar que quedo como booleano y NO como texto entre comillas."
  echo "Debe verse   \"rejectUnauthorized\": false"
  echo "y no         \"rejectUnauthorized\": \"false\""
  echo ""
  grep -n "rejectUnauthorized" "$HOME/.zowe/zowe.config.json" 2>/dev/null || true
  echo ""
  echo "Si aparece entre comillas, editar el archivo a mano:"
  echo "  $HOME/.zowe/zowe.config.json"
  echo ""
else
  echo ">> Sin cambios. Si la conexion falla por certificado,"
  echo "   volver a ejecutar este script."
fi

echo ""
echo "==================================================="
echo " Prueba de conexion"
echo "==================================================="
echo ""
echo "Ejecutando: zowe zosmf check status"
echo ""

if zowe zosmf check status; then
  echo ""
  echo ">> Conexion correcta."
  echo ""
  echo "Siguiente paso: ./scripts/zowe/verificar-entorno.sh"
else
  echo ""
  echo ">> La conexion fallo. Revisar en este orden:"
  echo ""
  echo "  1. Host y puerto correctos en ~/.zowe/zowe.config.json"
  echo "  2. Credenciales:  zowe config secure"
  echo "  3. Certificado:   volver a ejecutar este script y responder s"
  echo "  4. Red: verificar que la IP responde"
  echo "       ping <host>"
  echo "  5. Que tu usuario tenga permiso sobre z/OSMF. Si el error"
  echo "     menciona autorizacion y no certificado, es un tema de"
  echo "     perfiles de seguridad y hay que escalarlo."
  exit 1
fi
