# Instructivo de operación

**Agente de validación de reglas COBOL — Migración V4.2 a 6.4**

Dirección de Integraciones, Banco AV Villas · Equipo INSOFTCOL · Versión 2.0

---

## Antes de empezar: los conceptos mínimos

Si nunca has trabajado con estas herramientas, lee esta sección. Son cinco ideas y con ellas se entiende todo lo demás.

**Copybook.** Un pedazo de código COBOL guardado aparte, que muchos programas comparten. El programa lo incorpora con la sentencia `COPY`. Un copybook puede a su vez tener otros `COPY` adentro: a eso le llamamos el *árbol de copybooks*. Si al agente le falta uno, no puede saber qué tipo de dato tiene cada campo, y por eso marca el hallazgo como incompleto en vez de adivinar.

**Listado de compilación.** El reporte que genera el compilador cada vez que compila. Contiene qué versión del compilador se usó, qué opciones estaban activas y qué mensajes se emitieron. Casi siempre se descarta después de ver que terminó bien. Aquí es un insumo valioso.

**Opciones del compilador.** Ajustes que encienden o apagan verificaciones. En esta instalación varias están apagadas, y esa es la razón de que existan defectos silenciosos.

**Zowe.** Una herramienta que permite hablar con el mainframe desde el computador: leer bibliotecas, enviar trabajos, descargar resultados. Reemplaza tener que entrar por pantalla verde para cada cosa.

**Fase 1 y fase 2.** La estrategia del banco define dos momentos. En fase 1 se compila con todas las verificaciones activas para encontrar problemas; ahí muchos defectos abendean de forma ruidosa. En fase 2 se recompila sin ellas, buscando rendimiento, y la red de seguridad desaparece. Lo que no se encontró en fase 1, en fase 2 ya no avisa.

**Sonda.** Un programa COBOL diminuto que se compila a propósito para observar un comportamiento concreto. Solo queda una, `ZZB04`, porque el resto se resolvió leyendo la configuración real del sistema.

---

## Cómo está organizado el trabajo

Se abren **dos carpetas a la vez** en Visual Studio Code:

```
Workspace
├── fuentes/    el repositorio COBOL clonado de GitHub
└── agente/     este repositorio
```

El agente lee los programas directamente del clon. **No se copian archivos.** Esto importa por dos razones: se analiza exactamente lo que está versionado, y no hay riesgo de trabajar sobre una copia desactualizada.

---

## Mapa de etapas

```
ETAPA 1   Preparar el entorno              una vez
ETAPA 2   Conectar con el mainframe        una vez
ETAPA 3   Sondas del compilador            una vez
ETAPA 4   Analizar un programa             cada vez
ETAPA 5   Revisar y corregir               cada vez
ETAPA 6   Cerrar el entregable             por entregable
```

---

## ETAPA 1 · Preparar el entorno

**Se hace una sola vez por persona.**

### 1.1 Clonar los dos repositorios

```bash
git clone <url-fuentes> bancoavvillas
git clone <url-agente> cobol-rules-agent
```

Déjalos como carpetas hermanas, uno al lado del otro.

### 1.2 Descargar los manuales de IBM

```bash
cd cobol-rules-agent
bash scripts/descargar-docs-ibm.sh
```

Descarga nueve manuales oficiales y los convierte a texto. La conversión no es opcional: el agente no puede leer archivos PDF, y sin el texto no podría citar ninguna fuente.

Si algún manual falla por bloqueo de IBM, el script lo indica y se descarga desde el navegador. Las rutas están en `docs-ibm/INDICE.md`.

### 1.3 Configurar

```bash
cp scripts/zowe/config.env.ejemplo scripts/zowe/config.env
```

Abre `scripts/zowe/config.env` y completa:

| Variable | Qué poner |
|---|---|
| `REPO_FUENTES` | Ruta al clon de los fuentes, ej. `../bancoavvillas` |
| `COPYBOOK_PDS` | Bibliotecas de copybooks en el mainframe, separadas por coma |
| `SONDA_PDS` | Una biblioteca **personal** tuya para las sondas |

Los demás valores se completan en la etapa 3.

### 1.4 Configurar el editor de fuentes

Copia la plantilla al repositorio de **fuentes**, no al del agente:

```bash
cp plantillas/zapp.yaml ../bancoavvillas/zapp.yaml
```

Abre ese archivo y ajusta las rutas de copybooks a la estructura real del repositorio. El archivo trae comentarios explicando cada parte.

Este archivo le dice a Z Open Editor dónde buscar los copybooks. Sin él, el editor marca en rojo todo lo que venga de un copybook aunque el código esté perfecto. Como se versiona en Git, todo el equipo lo hereda.

### 1.5 Crear el workspace

```bash
cp plantillas/proyecto.code-workspace ./proyecto.code-workspace
code proyecto.code-workspace
```

Ajusta la ruta de la carpeta `fuentes` si tus repositorios no quedaron como carpetas hermanas.

### 1.6 Extensiones de Visual Studio Code

Necesarias:

- **IBM Z Open Editor** — entiende COBOL, JCL y CICS, y resuelve los copybooks
- **Zowe Explorer** — conexión al mainframe
- **GitHub Copilot** y **GitHub Copilot Chat** — donde vive el agente

> **Importante.** Si tienes instalada **COBOL Language Support** de Broadcom, deshabilítala en este workspace. Las dos extensiones hacen lo mismo y entran en conflicto; cuando eso pasa, ninguna funciona y el editor reporta que la extensión de COBOL está inactiva. El workspace ya viene con la recomendación configurada.

### 1.7 Verificar

```bash
./scripts/zowe/verificar-entorno.sh
```

Revisa todo y dice qué falta. `[FALLA]` impide operar, `[AVISO]` limita algunas reglas pero permite trabajar.

---

## ETAPA 2 · Conectar con el mainframe

**Se hace una sola vez por persona.**

```bash
./scripts/zowe/configurar-zowe.sh
```

El script pregunta lo necesario y prueba la conexión.

### Sobre el certificado

Te va a preguntar si desactivas la validación del certificado. Conviene entender qué significa.

z/OSMF usa un certificado generado por el propio mainframe, no emitido por una autoridad reconocida. Los navegadores y Zowe lo rechazan por defecto, y el navegador puede negarse del todo si además está vencido.

Desactivar la validación significa aceptar que no hay garantía criptográfica de que el servidor sea el que dice ser. Contra una dirección IP interna y fija el riesgo es bajo, y es la práctica corriente con z/OSMF autofirmado. Aun así, si el certificado está vencido conviene reportarlo: es higiene que alguien debería corregir.

**No necesitas que el navegador funcione.** Zowe tiene su propio control, independiente del navegador.

### Si falla

| Mensaje | Causa | Qué hacer |
|---|---|---|
| Certificado | Autofirmado o vencido | Volver a correr el script y responder `s` |
| Autorización o permisos | Tu usuario no tiene perfil sobre z/OSMF | Escalarlo. No se resuelve del lado del cliente |
| No responde el host | Red o dirección incorrecta | Verificar con `ping` y revisar host y puerto |

---

## ETAPA 3 · Confirmar la configuración

**Se hace una sola vez para todo el equipo.** Casi todo ya está hecho.

### 3.1 Lo que ya está verificado

Lee `entorno/CONFIGURACION-ACTUAL.md`. Contiene, verificado sobre el sistema real:

- Compilador **6.4**, nivel `P240621`
- Opciones reales, leídas de `SYS1.AVDE230.ALLPROGS.PARMLIB(CBLO62BD)`
- Mecanismo de compilación por comandos TSO, no por JCL
- Orden real de bibliotecas de copybooks
- Restricción de nomenclatura de miembros

Un dato que cambia cómo se lee todo lo demás: **las verificaciones están activas.** `INITCHECK(STRICT)`, `NUMCHECK` con abend, `SSRANGE` y `DIAGTRUNC`. Eso es la fase 1 de la estrategia del banco.

### 3.2 Lo que falta verificar

Cuatro puntos, listados en la sección 6 de ese archivo. El más importante:

Abre `SYS1.AVDE230.ALLPROGS.PARMLIB(CBLO62BD)` y baja con `F8` más allá de la línea 5 — el miembro continúa. Busca si incluye `RULES` y `PARMCHECK`.

| Encuentras | Significa |
|---|---|
| `RULES(...)` con subopciones | Alineado con la estrategia del banco |
| `NORULES` o nada | Desviación frente al estándar interno. Es la regla `OPT-02` |

Anota lo que encuentres en la sección 2 del archivo de configuración.

### 3.3 SONDA04, opcional pero recomendada

Es la única sonda que sobrevivió, porque prueba comportamiento del lenguaje y no configuración. Demuestra sobre este mismo sistema que `INITIALIZE` no alcanza las vistas `REDEFINES`.

Cuesta una compilación y una ejecución. Instrucciones en `sondas/README.md`.

Vale la pena porque convierte la regla crítica central en evidencia propia. Ante el negocio, "lo probamos aquí" pesa distinto que "lo dice el manual".

### 3.4 Publicar

```bash
git add entorno/CONFIGURACION-ACTUAL.md
git commit -m "Configuracion verificada del entorno AVDE"
git push
```

**Criterio de salida:** sección 6 de `CONFIGURACION-ACTUAL.md` sin pendientes, o los pendientes documentados.

---

## ETAPA 4 · Analizar un programa

**Se hace cada vez que se va a revisar un programa.**

### 4.1 Resolver el árbol de copybooks

Antes de analizar, confirma que el agente va a poder ver todo lo que el programa necesita:

```bash
python3 scripts/copybooks/resolver-copybooks.py ../bancoavvillas/ruta/PGMXXXX.CBL
```

Muestra el árbol completo de `COPY`, incluidos los anidados, y marca lo que no encontró.

Si faltan copybooks, tráelos del mainframe:

```bash
python3 scripts/copybooks/resolver-copybooks.py ../bancoavvillas/ruta/PGMXXXX.CBL --descargar
```

**Presta atención a la sección de desviación.** Si un copybook aparece en el mainframe pero no en el repositorio clonado, significa que el programa que se compila no es igual al que se versiona. Eso es un riesgo de migración por sí mismo, aparte de cualquier regla del catálogo, y hay que reportarlo al líder técnico.

### 4.2 Abrir el agente

En Visual Studio Code, abre Copilot Chat y selecciona el agente `cobol-rules-validator` en el selector de agentes.

Si no aparece, ver la tabla de problemas frecuentes al final.

### 4.3 Arranque de sesión

Pega el prompt **P0** de `prompts/00-prompts.md`. Una vez por sesión de trabajo, no por cada programa.

El agente carga el catálogo, revisa qué información tiene disponible y responde con una tabla de las seis familias de reglas indicando cuáles puede evaluar.

Si sale mucho `NO EVALUABLE`, falta algo de las etapas anteriores.

### 4.4 Analizar

Pega el prompt **P1**, indicando la ruta del programa dentro de la carpeta `fuentes`.

Para revisar varios programas y decidir por dónde empezar, usa el prompt **P3**, que produce un tablero de priorización sin entrar al detalle de cada uno.

---

## ETAPA 5 · Revisar y corregir

Cada hallazgo trae una marca. Esto es lo que se hace con cada una:

Cada hallazgo trae **dos severidades**: la de fase 1, con las verificaciones activas, y la de fase 2, sin ellas. **El veredicto se decide por la de fase 2**, porque es la configuración que llega a producción.

Un hallazgo que en fase 1 sale como `ALTO` porque abendea en pruebas, y en fase 2 como `CRITICO` porque ya no avisa, se trata como `CRITICO`.

| Marca | Significa | Acción | ¿Bloquea? |
|---|---|---|---|
| `CRITICO` | Puede cambiar el resultado sin avisar en fase 2 | Corregir antes de promover | Sí |
| `ALTO` | Puede fallar, pero deja rastro | Corregir o justificar por escrito | Sí, salvo justificación |
| `MEDIO` / `BAJO` | Riesgo menor o higiene | Registrar como deuda técnica | No |
| `FALSO-POSITIVO-CONFIRMADO` | Confirmado como defecto del compilador | No tocar el código. Documentarlo | No |
| `POSIBLE-FALSO-POSITIVO` | Podría ser defecto del compilador | Verificar el nivel de PTF contra el APAR citado **antes** de tocar nada | Sí, hasta resolver |
| `INCOMPLETO` | Falta un copybook | Volver al paso 4.1 y reprocesar | Sí |
| `SIN-RESPALDO` | El agente no halló sustento documental | Tratar como observación | No |
| `NO EVALUABLE` | Falta información del entorno | Documentar como límite de alcance | No |

> **La regla más importante de esta etapa.** Nunca modifiques código por un hallazgo marcado `POSIBLE-FALSO-POSITIVO` sin correr antes la sonda. Es el error más caro del proceso, porque lleva a reescribir código que estaba bien.

Los hallazgos de la familia `OPT` no son acción del equipo de desarrollo. Se acumulan en un documento de recomendaciones hacia el área de sistemas.

---

## ETAPA 6 · Cerrar el entregable

**Responsable: líder técnico.**

| Veredicto | Condición |
|---|---|
| `APROBADO` | Sin `CRITICO` ni `ALTO` pendientes |
| `APROBADO CON CONDICIONES` | Sin `CRITICO`; los `ALTO` justificados por escrito |
| `NO APROBADO` | Al menos un `CRITICO` sin remediar |

En el cierre se declaran además los límites de alcance, que con los permisos actuales son permanentes:

- No se confirma qué correcciones tiene aplicadas el compilador. Solo se conoce el nivel de servicio `P240621`, no el inventario de PTF.
- No se modifican las opciones de compilación de producción.
- Las reglas RDF-02 y NUM-02 se detectan por estructura, pero solo se confirman ejecutando con datos reales.
- Si se detectaron desviaciones entre repositorio y mainframe, se listan explícitamente.

Esta declaración no es un descargo. Convierte un riesgo detectado y no verificable en un **riesgo transferido**, que es la posición correcta del equipo de desarrollo. Es trazabilidad.

---

## Problemas frecuentes

| Síntoma | Causa probable | Solución |
|---|---|---|
| El agente no aparece en el selector | Política de GitHub de la organización, o carpeta mal abierta | Abrir el `.code-workspace`, no una subcarpeta. Si persiste, pedir al administrador de GitHub que habilite agentes personalizados |
| El editor marca todo en rojo | Falta `zapp.yaml` o rutas mal configuradas | Etapa 1.4 |
| "la extensión de COBOL está inactiva" | Dos extensiones de COBOL en conflicto | Deshabilitar COBOL Language Support de Broadcom |
| Todos los hallazgos salen `SIN-RESPALDO` | Los manuales no se convirtieron a texto | Etapa 1.2 |
| Todo sale `NO EVALUABLE` | Falta completar la configuración verificada | Etapa 3 |
| Hallazgos con líneas que no corresponden | Faltan copybooks | Etapa 4.1 |
| Zowe no conecta | Certificado o permisos | Etapa 2 |
| El agente propone acciones de administrador | El perfil del agente no se está aplicando | Verificar que el agente seleccionado sea `cobol-rules-validator` |

---

## Glosario

| Término | Qué es |
|---|---|
| **APAR** | Número del reporte de un defecto de IBM. El "ticket del error" |
| **PTF** | La corrección que arregla un APAR. La aplica el administrador del sistema |
| **Nivel de servicio** | Código como `P240621` en el encabezado del listado. Indica hasta qué correcciones está actualizado el compilador |
| **Copybook** | Código COBOL compartido que los programas incorporan con `COPY` |
| **Árbol de copybooks** | El conjunto completo, incluidos los que un copybook incorpora a su vez |
| **PDS** | Biblioteca del mainframe. Contiene miembros, equivalente a una carpeta con archivos |
| **Miembro** | Cada archivo dentro de un PDS |
| **Listado** | El reporte que produce el compilador |
| **RC** | Código de retorno. 0 correcto, 4 con advertencias, 8 o más con errores |
| **z/OSMF** | Servicio del mainframe que expone una interfaz web. Es a lo que se conecta Zowe |
| **Sonda** | Programa mínimo compilado a propósito para observar el comportamiento del compilador |
| **Fase 1 / Fase 2** | Los dos momentos de la estrategia del banco: con verificaciones activas y sin ellas |
| **OPTFILE** | Opción que hace que el compilador lea sus opciones de un archivo aparte, no del JCL |
| **CLIST** | Programa de comandos de TSO. Es lo que hay detrás de `C62BATD` y `CATCICSD` |
| **Hallazgo silencioso** | Condición de riesgo que el compilador no reporta. Son los `CRITICO` |
| **Desviación repositorio/host** | Cuando el código del mainframe no coincide con el versionado en Git |
