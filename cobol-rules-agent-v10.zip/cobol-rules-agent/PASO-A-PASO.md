# Paso a paso de implementación

**Agente de validación de reglas COBOL — Migración V4.2 a 6.4**

Dirección de Integraciones, Banco AV Villas · Equipo INSOFTCOL · Versión 3.0

---

## Para quién es este documento

Para el equipo que va a montar y poner en marcha el agente. No supone conocimiento previo de Zowe, agentes de IA ni de las opciones del compilador COBOL. Cada paso indica quién lo hace, cuánto tarda y cómo saber si quedó bien.

La operación diaria, una vez montado esto, está en `INSTRUCTIVO.md`.

---

## Qué se va a montar

Un asistente dentro de Visual Studio Code que revisa programas COBOL y señala los riesgos de la migración a la versión 6.4, con especial atención a los que **el compilador no reporta**.

Se trabaja con dos carpetas abiertas a la vez:

```
Workspace
├── fuentes/    el repositorio COBOL clonado de GitHub
└── agente/     el repositorio del agente
```

El agente lee los programas directamente del clon de Git. No se copian archivos entre carpetas.

---

## Resumen de pasos

| Paso | Quién | Duración |
|---|---|---|
| 1 · Montar el repositorio del agente | Líder técnico | 30 min |
| 2 · Publicarlo en Git | Líder técnico | 15 min |
| 3 · Preparar cada estación de trabajo | Cada desarrollador | 20 min |
| 4 · Conectar con el mainframe | Cada desarrollador | 15 min |
| 5 · Configurar el editor de fuentes | Líder técnico, una vez | 30 min |
| 6 · Confirmar la configuración | Líder técnico, una vez | 1 hora |
| 7 · Programa piloto | Líder técnico y desarrollador | 2 horas |
| 8 · Sesión con el equipo | Líder técnico | 1 hora |

---

## PASO 1 · Montar el repositorio del agente

**Responsable:** líder técnico · **Duración:** 30 minutos

### 1.1 Requisitos previos

| Herramienta | Cómo instalarla en macOS | Para qué |
|---|---|---|
| Python 3 | Viene con el sistema | Los scripts de análisis |
| poppler | `brew install poppler` | Convertir los manuales PDF a texto |
| Zowe CLI | `npm install -g @zowe/cli` | Hablar con el mainframe |
| Git | Viene con Xcode Tools | Versionar |

### 1.2 Descargar los manuales de IBM

```bash
cd cobol-rules-agent
bash scripts/descargar-docs-ibm.sh
```

Baja nueve manuales oficiales, seis de la versión 6.4 y tres de la 4.2, y los convierte a texto.

**La conversión a texto no es opcional.** El agente no puede leer archivos PDF. Sin el texto no podría citar ninguna fuente, y todos sus hallazgos saldrían marcados como sin respaldo documental.

IBM bloquea las descargas automatizadas de forma intermitente. Si algún manual falla, el script lo indica; se descarga desde el navegador y se guarda con el nombre exacto que dice `docs-ibm/INDICE.md`.

### 1.3 Verificar

```bash
ls -1 docs-ibm/6.4/txt/*.txt | wc -l
ls -1 docs-ibm/origen/txt/*.txt | wc -l
```

Deben salir `6` y `3`.

```bash
head -5 docs-ibm/6.4/txt/Migration-Guide-GC27-8715-03.txt
```

Si aparece texto legible, quedó bien. Si aparecen caracteres extraños, el archivo se descargó dañado y hay que rehacerlo.

- [ ] Nueve archivos de texto presentes y legibles

---

## PASO 2 · Publicarlo en Git

**Responsable:** líder técnico · **Duración:** 15 minutos

### 2.1 Qué se versiona y qué no

Los archivos PDF pesan unos 20 MB y **no** van al repositorio. Los archivos de texto sí: pesan unos 13 MB y son los que el agente consulta.

Esta decisión tiene una razón práctica. IBM bloquea las descargas automatizadas y algunos servidores están filtrados por la red corporativa. Si cada persona tuviera que reconstruir los manuales por su cuenta, cada una repetiría el mismo forcejeo. Versionar el texto hace que el repositorio funcione sin depender de la red externa.

El `.gitignore` ya viene configurado. Verifica que incluya:

```
docs-ibm/**/*.pdf
scripts/zowe/config.env
zowe.config.user.json
salidas/*
```

Las dos líneas del medio son de seguridad: **las credenciales del mainframe nunca deben llegar al repositorio.**

### 2.2 Publicar

```bash
git init
git add .
git commit -m "Agente de validacion de reglas COBOL V4.2 a 6.4"
git remote add origin <url-del-repositorio>
git push -u origin main
```

- [ ] Repositorio publicado
- [ ] Los archivos de texto versionados y los PDF excluidos
- [ ] Ninguna credencial en el repositorio

---

## PASO 3 · Preparar cada estación de trabajo

**Responsable:** cada desarrollador · **Duración:** 20 minutos

### 3.1 Clonar los dos repositorios

```bash
git clone <url-fuentes> bancoavvillas
git clone <url-agente> cobol-rules-agent
```

Djalos como carpetas hermanas.

### 3.2 Extensiones de Visual Studio Code

| Extensión | Para qué |
|---|---|
| IBM Z Open Editor | Entiende COBOL, JCL y CICS. Resuelve los copybooks |
| Zowe Explorer | Conexión al mainframe |
| GitHub Copilot | Motor del agente |
| GitHub Copilot Chat | Donde se conversa con el agente |

> **Punto de atención.** Si está instalada **COBOL Language Support** de Broadcom, hay que deshabilitarla en este workspace. Las dos extensiones cubren lo mismo y entran en conflicto: cuando eso ocurre ninguna funciona, y el editor reporta que la extensión de COBOL está inactiva. Se elige Z Open Editor porque además maneja JCL, que Broadcom no soporta, y porque sigue el dialecto de IBM, que es el compilador destino.

### 3.3 Crear el workspace

```bash
cd cobol-rules-agent
cp plantillas/proyecto.code-workspace ./proyecto.code-workspace
```

Abre ese archivo y ajusta la ruta de la carpeta `fuentes` si los repositorios no quedaron como carpetas hermanas. Luego:

```bash
code proyecto.code-workspace
```

**Abre siempre el workspace, no una carpeta suelta.** Si abres solo una carpeta, el agente no aparece en el selector.

### 3.4 Configurar

```bash
cp scripts/zowe/config.env.ejemplo scripts/zowe/config.env
```

Completa `REPO_FUENTES`, `COPYBOOK_PDS` y `SONDA_PDS`. El archivo trae comentarios explicando cada valor.

### 3.5 Verificar que el agente aparece

Abre Copilot Chat y despliega el selector de agentes. Debe aparecer `cobol-rules-validator`.

Si no aparece, revisa en este orden:

1. Que hayas abierto el `.code-workspace` y no una subcarpeta.
2. Que exista el archivo `.github/agents/cobol-rules-validator.agent.md`.
3. Que Visual Studio Code y la extensión de Copilot estén actualizados.
4. Que la política de GitHub de la organización permita agentes personalizados.

> El punto 4 es el bloqueo más frecuente en entornos bancarios, donde esta función suele venir restringida por defecto. Conviene gestionarlo con el administrador de GitHub **antes** de convocar la sesión del paso 8, o la sesión se cae en el primer minuto.

- [ ] Los dos repositorios clonados
- [ ] Extensiones instaladas y sin conflicto
- [ ] El agente aparece en el selector

---

## PASO 4 · Conectar con el mainframe

**Responsable:** cada desarrollador · **Duración:** 15 minutos

```bash
./scripts/zowe/configurar-zowe.sh
```

El script pregunta lo necesario y prueba la conexión al final.

### Sobre el certificado

El script preguntará si desactivas la validación del certificado. Conviene entender la decisión antes de responder.

El mainframe presenta un certificado que él mismo generó, no emitido por una autoridad reconocida. Por eso el navegador y Zowe lo rechazan. Si además está vencido, el navegador puede negarse por completo sin ofrecer continuar.

Desactivar la validación significa aceptar que no existe garantía criptográfica de que el servidor sea el que dice ser. Contra una dirección IP interna y fija el riesgo es bajo, y es la práctica habitual con z/OSMF autofirmado. Aun así, si el certificado está vencido conviene reportarlo por el canal correspondiente: es higiene que alguien debería corregir.

**No hace falta que el navegador funcione.** Zowe tiene su propio control de certificados, independiente del navegador.

### Si la conexión falla

| Mensaje | Causa | Qué hacer |
|---|---|---|
| Menciona certificado | Autofirmado o vencido | Volver a correr el script y responder que sí |
| Menciona autorización o permisos | Tu usuario no tiene perfil sobre z/OSMF | Escalarlo. No se resuelve desde el computador |
| No responde | Red, dirección o puerto | Verificar con `ping` y revisar host y puerto |

### Verificación general

```bash
./scripts/zowe/verificar-entorno.sh
```

Revisa herramientas, manuales, configuración y conexión, y dice exactamente qué falta.

- [ ] `zowe zosmf check status` responde correctamente
- [ ] La verificación de entorno pasa sin fallas

---

## PASO 5 · Configurar el editor de fuentes

**Responsable:** líder técnico · **Duración:** 30 minutos, una sola vez

Este paso resuelve el problema de que el editor marque en rojo código que está bien, simplemente porque no encuentra los copybooks.

### 5.1 Averiguar dónde están los copybooks

En el repositorio de fuentes clonado, busca alguno de los copybooks que los programas referencian:

```bash
cd ../bancoavvillas
find . -iname "SOY310*" -o -iname "GEY593*"
```

| Resultado | Qué significa |
|---|---|
| Aparecen archivos | Los copybooks están en el repositorio. Configuración local, sin depender de la red |
| No aparece nada | El repositorio trae programas pero no copybooks. Habrá que traerlos del mainframe |

Fíjate también si los archivos tienen extensión o no. Los repositorios clonados de bibliotecas del mainframe suelen tener archivos sin extensión, y eso cambia cómo hay que configurar la búsqueda.

### 5.2 Crear el archivo de configuración

```bash
cp ../cobol-rules-agent/plantillas/zapp.yaml ./zapp.yaml
```

Va en la raíz del repositorio de **fuentes**, no en el del agente. Abre el archivo y ajusta las rutas a lo que encontraste en el paso anterior. Trae comentarios explicando cada sección.

Este archivo se versiona en Git, así que todo el equipo hereda la misma configuración. Es la razón de que este paso se haga una sola vez.

### 5.3 Comprobar

Abre cualquier programa COBOL en Visual Studio Code. Los `COPY` deben dejar de aparecer subrayados en rojo, y al pasar el cursor sobre el nombre de un copybook debe mostrarse su contenido.

### 5.4 Publicar

```bash
git add zapp.yaml
git commit -m "Configuracion de resolucion de copybooks"
git push
```

- [ ] `zapp.yaml` creado y ajustado
- [ ] Los `COPY` se resuelven en el editor
- [ ] Publicado para todo el equipo

---

## PASO 6 · Confirmar la configuración

**Responsable:** líder técnico · **Duración:** 1 hora

Este paso reemplaza al kit de sondas de la versión anterior. La mayor parte del trabajo ya está hecha.

### 6.1 Lo que ya está verificado

Lee `entorno/CONFIGURACION-ACTUAL.md`. Contiene, comprobado sobre el sistema AVDE real:

| Dato | Valor |
|---|---|
| Compilador | Enterprise COBOL **6.4**, nivel `P240621` |
| Archivo de opciones | `SYS1.AVDE230.ALLPROGS.PARMLIB(CBLO62BD)` |
| Mecanismo | Comandos TSO (`C62BATD`, `C62CICSD`), no JCL propio |
| Copybooks | `DESA.AV01.COPYLIB`, luego `PROD.AV00.COPYLIB` |

Y un dato que cambia cómo se lee todo lo demás: **las verificaciones del compilador están activas.** `INITCHECK(STRICT)`, `NUMCHECK` con abend, `SSRANGE` y `DIAGTRUNC`. Corresponde a la fase 1 de la estrategia de la Gerencia de Desarrollo.

### 6.2 Por qué el agente sigue haciendo falta

Conviene tenerlo claro para explicarlo al equipo. Con esas verificaciones activas, muchos defectos abendean en pruebas de forma ruidosa. Quedan dos huecos:

**La cobertura de las pruebas.** La verificación en ejecución solo alcanza los caminos que los datos recorren. Una condición en una rama no ejercitada pasa limpia y nadie se entera.

**La fase 2.** La estrategia indica recompilar sin verificaciones para calidad y producción. Ahí desaparece la red: lo que no se encontró antes, ya no avisa.

Por eso cada hallazgo trae dos severidades, y el veredicto se decide por la de fase 2.

### 6.3 Lo que falta verificar

Cuatro puntos, en la sección 6 del archivo de configuración. El más importante:

Abre `SYS1.AVDE230.ALLPROGS.PARMLIB(CBLO62BD)` y baja con `F8` más allá de la línea 5, porque el miembro continúa. Busca si incluye `RULES` y `PARMCHECK`.

| Encuentras | Significa |
|---|---|
| `RULES(...)` con subopciones | Alineado con la estrategia del banco |
| `NORULES`, o no aparece | Desviación frente al estándar interno. Es la regla `OPT-02` |

Anota lo encontrado en la sección 2 del archivo.

### 6.4 La sonda ZZB04, opcional pero recomendada

Es la única sonda que sobrevivió, porque prueba comportamiento del lenguaje y no configuración. Demuestra sobre este mismo sistema que `INITIALIZE` no alcanza las vistas `REDEFINES`.

Cuesta una compilación y una ejecución. Instrucciones en `sondas/README.md`.

Vale la pena porque convierte la regla crítica central del catálogo en evidencia propia del equipo. Ante el negocio y ante el GATE, haberlo probado aquí pesa distinto que citar el manual.

Dos precauciones: el nombre debe ser `ZZB04` y no `SONDA04`, porque el comando de compilación valida que el tercer carácter del miembro esté en una lista permitida. Y el miembro tiene que pasar por `DESA.AV00.BATCHLIB`, que es biblioteca compartida del área, así que conviene avisar y borrarlo al terminar.

### 6.5 Publicar

```bash
git add entorno/CONFIGURACION-ACTUAL.md
git commit -m "Configuracion verificada del entorno AVDE"
git push
```

- [ ] Sección 6 del archivo de configuración sin pendientes, o los pendientes documentados

---

## PASO 7 · Programa piloto

**Responsable:** líder técnico y un desarrollador · **Duración:** 2 horas

No se arranca con un lote. Se escoge **un** programa representativo: que use copybooks, que tenga al menos una estructura `REDEFINES` y que pertenezca a un módulo que el equipo conozca bien.

### 7.1 Resolver el árbol de copybooks

```bash
cd cobol-rules-agent
python3 scripts/copybooks/resolver-copybooks.py ../bancoavvillas/ruta/PGMXXXX.CBL
```

Muestra el árbol completo de `COPY`, incluidos los anidados, y marca lo que no encontró. Si faltan, agregar `--descargar` para traerlos del mainframe.

**Revisa la sección de desviación.** Si un copybook existe en el mainframe pero no en el repositorio, el programa que se compila no es igual al que se versiona. Es un hallazgo por sí mismo y hay que reportarlo.

### 7.2 Analizar

Prompt **P0** para el arranque de sesión, y luego prompt **P1** con la ruta del programa. Los textos están en `prompts/00-prompts.md`.

### 7.3 Validar contra criterio humano

Este paso define si el montaje sirve. Revisar hallazgo por hallazgo:

| Pregunta de control | Si la respuesta es no |
|---|---|
| ¿La cita del fuente corresponde a la línea real? | Falla de lectura. Revisar copybooks |
| ¿El respaldo en el manual existe donde dice? | Los manuales están incompletos o mal convertidos |
| ¿La severidad asignada es razonable? | Ajustar el catálogo, no el agente |
| ¿Falta algún riesgo que el equipo sí identifica? | Incorporar una regla nueva al catálogo |

Los ajustes van a `reglas/catalogo-reglas.md`. El perfil del agente casi nunca necesita modificarse.

- [ ] Piloto analizado y revisado con criterio humano
- [ ] Ajustes al catálogo aplicados y publicados

---

## PASO 8 · Sesión con el equipo

**Responsable:** líder técnico · **Duración:** 1 hora

### 8.1 Agenda sugerida

| Bloque | Contenido | Tiempo |
|---|---|---|
| 1 | El problema: los dos huecos que deja la verificación en ejecución | 15 min |
| 2 | Demostración con ZZB04, que lo hace tangible | 10 min |
| 3 | Recorrido del `INSTRUCTIVO`, etapas 4 y 5 | 20 min |
| 4 | Los tres textos de uso diario: P0, P1 y P3 | 15 min |

### 8.2 Acuerdos a dejar por escrito

- Un hallazgo `CRITICO` bloquea la promoción.
- **Nunca se modifica código por un hallazgo marcado `POSIBLE-FALSO-POSITIVO` sin correr antes la sonda que el agente indica.** Es el error más costoso del proceso: lleva a reescribir código correcto.
- Los hallazgos de la familia `OPT` no son acción del equipo; se acumulan como recomendación hacia el área de sistemas.
- Las desviaciones entre repositorio y mainframe se reportan siempre, aparte del catálogo.
- Todo ajuste al catálogo pasa por pull request.

- [ ] Sesión realizada
- [ ] Acuerdos documentados

---

## Roles

| Rol | Responsabilidad |
|---|---|
| Líder técnico | Monta y publica el repositorio, configura el editor, valida el piloto, aprueba cambios al catálogo y emite el veredicto de cierre |
| Líder técnico | Verifica y publica la configuración real del entorno |
| Desarrollador | Resuelve copybooks, analiza programas y remedia hallazgos |
| Administrador de GitHub | Habilita la política de agentes personalizados |
| Área de sistemas | Recibe las recomendaciones de la familia `OPT`. No participa en la operación diaria |

---

## Lista de verificación final

- [ ] Nueve manuales convertidos a texto y legibles
- [ ] Repositorio del agente publicado, sin PDF y sin credenciales
- [ ] Los dos repositorios clonados en cada estación
- [ ] Extensiones instaladas, sin conflicto entre editores de COBOL
- [ ] El agente aparece en el selector en al menos dos estaciones
- [ ] Conexión al mainframe funcionando
- [ ] `zapp.yaml` publicado y los `COPY` resolviendo en el editor
- [ ] Configuración del entorno verificada y publicada
- [ ] Un programa piloto analizado y validado
- [ ] Sesión con el equipo realizada y acuerdos documentados

---

## Problemas frecuentes

| Síntoma | Causa probable | Paso |
|---|---|---|
| El agente no aparece en el selector | Se abrió una carpeta en vez del workspace, o política de GitHub | 3.5 |
| El editor marca todo en rojo | Falta `zapp.yaml` o rutas mal ajustadas | 5 |
| "la extensión de COBOL está inactiva" | Dos extensiones de COBOL en conflicto | 3.2 |
| Todos los hallazgos sin respaldo documental | Los manuales no se convirtieron a texto | 1.2 |
| Todo sale como no evaluable | Falta completar la configuración verificada | 6 |
| Hallazgos con líneas que no corresponden | Faltan copybooks | 7.1 |
| Zowe no conecta | Certificado o permisos | 4 |
