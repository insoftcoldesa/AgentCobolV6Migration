# CobolRulesAI

Agente que revisa código COBOL y detecta riesgos de la migración de **IBM Enterprise COBOL V4.2 a la versión 6.4**.

Dirección de Integraciones, Banco AV Villas · Equipo INSOFTCOL

---

## Qué problema resuelve

Cuando un programa COBOL pasa de la versión 4.2 a la 6.4, la mayoría de los errores se ven solos: el programa no compila y hay que corregirlo. Esos no son el problema.

El problema son los defectos que **llegan a producción sin señal**: código que compila y prueba bien, y allí devuelve un resultado distinto al que devolvía antes.

La instalación compila hoy con las verificaciones activas — `INITCHECK(STRICT)`, `NUMCHECK` con abend, `SSRANGE`, `DIAGTRUNC` — que es la fase 1 de la estrategia del banco. En esa fase muchos defectos abendean de forma ruidosa. Pero quedan dos huecos:

**La verificación en ejecución solo cubre lo que los datos de prueba recorren.** Una condición en una rama no ejercitada pasa limpia.

**La fase 2 apaga la red.** La estrategia indica recompilar sin verificaciones para calidad y producción. Lo que no se encontró antes, ya no avisa.

El agente lee el código fuente y busca esas condiciones antes de compilar, respaldando cada hallazgo en la documentación oficial de IBM y en la estrategia del propio banco.

---

## Por dónde empezar

| Si eres | Lee |
|---|---|
| Quien instala por primera vez | `PASO-A-PASO.md` |
| Desarrollador que va a analizar programas | `INSTRUCTIVO.md`, etapas 3 y 4 |
| Líder técnico que aprueba entregables | `INSTRUCTIVO.md`, etapa 6 |
| Quien quiere entender por qué está hecho así | `GUIA-USO.md` |
| Quien va a auditar o ampliar las reglas | `reglas/catalogo-reglas.md` |
| Quien no conoce los términos | Glosario al final de `INSTRUCTIVO.md` |

---

## Cómo se organiza el trabajo

Se trabaja con **dos carpetas abiertas al mismo tiempo** en Visual Studio Code:

```
Workspace
├── fuentes/      el repositorio COBOL clonado de GitHub
└── agente/       este repositorio: reglas, documentación y scripts
```

El agente lee los fuentes directamente del clon. **No se copian archivos de un lado a otro.** Lo que ves en Git es lo que el agente analiza.

---

## Contenido

```
cobol-rules-agent/
├── PASO-A-PASO.md                    instalación, una sola vez
├── INSTRUCTIVO.md                    operación diaria, por etapas
├── GUIA-USO.md                       decisiones de diseño y límites
├── .github/agents/
│   └── cobol-rules-validator.agent.md    perfil del agente
├── reglas/catalogo-reglas.md         37 reglas en 6 familias
├── prompts/00-prompts.md             textos listos para pegar
├── plantillas/
│   ├── zapp.yaml                     configuración del editor
│   └── proyecto.code-workspace       workspace de dos carpetas
├── entorno/
│   └── CONFIGURACION-ACTUAL.md       configuración real verificada
├── plantillas/zapp.yaml              resolución de copybooks
├── sondas/                           ZZB04, la única sonda vigente
├── docs-ibm/                         manuales oficiales de IBM
└── scripts/
    ├── descargar-docs-ibm.sh         descarga los manuales
    ├── copybooks/
    │   └── resolver-copybooks.py     resuelve el árbol de COPY
    └── zowe/
        ├── configurar-zowe.sh        conexión al mainframe
        ├── verificar-entorno.sh      diagnóstico del montaje
        ├── ejecutar-sondas.sh        kit de sondas automatizado
        ├── parse-listado.py          lee listados de compilación
        └── generar-resultados.py     interpreta las sondas
```

---

## Instalación en cinco comandos

```bash
git clone <url-del-repositorio> cobol-rules-agent
cd cobol-rules-agent
bash scripts/descargar-docs-ibm.sh
cp scripts/zowe/config.env.ejemplo scripts/zowe/config.env
./scripts/zowe/verificar-entorno.sh
```

El último comando dice exactamente qué falta. Después, seguir `PASO-A-PASO.md`.

---

## Las seis familias de reglas

| Familia | Qué revisa | Reglas |
|---|---|---|
| `INIT` | Variables que se usan antes de recibir valor | 7 |
| `RDF` | Estructuras superpuestas con `REDEFINES` | 6 |
| `NUM` | Datos numéricos y literales mal usados | 6 |
| `MIG` | Diferencias específicas entre V4.2 y 6.4 | 9 |
| `FLW` | Defectos conocidos del propio compilador | 3 |
| `OPT` | Configuración de compilación y fases | 6 |

---

## Principio de diseño

Cada hallazgo exige **tres evidencias**: la línea exacta del fuente, el identificador de la regla, y la sección del manual de IBM que lo sustenta. Si falta alguna, el agente lo degrada a observación y no cuenta para la aprobación del entregable.

Cada hallazgo trae además **dos severidades**: una para fase 1, con las verificaciones activas, y otra para fase 2, sin ellas. El veredicto se decide por la de fase 2, que es la configuración que llega a producción.

Cuando al agente le falta información, lo dice. Un informe que declara `NO EVALUABLE` es más útil que uno completo pero inventado.

---

## Relación con los demás agentes

Este agente trabaja sobre código. No genera historias de usuario, especificaciones ni planes de prueba: eso corresponde a RefinAI, ReqMasterAI, ScopeAI, SolicitaAI y TestForgeAI.

Mantiene el veredicto GATE y la clasificación D/C/M/P para consolidar con los analizadores existentes.
