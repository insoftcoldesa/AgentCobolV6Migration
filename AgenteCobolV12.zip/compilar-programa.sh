#!/usr/bin/env bash
#
# Compila un programa a traves del comando TSO real de la instalacion
# (C62BATD, C62CICSD, o sus equivalentes V4), captura el job, baja el
# listado y lo interpreta con parse-listado.py.
#
# NO ES UNA OPERACION DE SOLO LECTURA. Escribe un objeto real en la
# biblioteca de trabajo compartida y en la LOADLIB correspondiente.
# Requiere confirmacion explicita del usuario en cada corrida; este
# script nunca se invoca en un bucle ni de forma silenciosa.
#
# Uso:
#   compilar-programa.sh <miembro> <batch|cics> <v4|v6|ambas> [--subir <archivo-local>]
#
# Ejemplos:
#   compilar-programa.sh ABK110 cics v6
#   compilar-programa.sh KLB113 batch ambas
#   compilar-programa.sh ABK110 cics v6 --subir fuentes/bavv-gd-zos/AV00/CICSLIB/AB/ABK110.CBL
#
# El flag --subir sincroniza el fuente local hacia la biblioteca de
# ENTRADA antes de compilar. Sin el, el comando compila lo que YA este
# en el mainframe, que puede no coincidir con el clon de Git. El script
# lo advierte explicitamente si no se usa.

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$ROOT"

CONFIG="scripts/zowe/config.env"
if [ ! -f "$CONFIG" ]; then
  echo "No existe $CONFIG. Copiar desde config.env.ejemplo y completar."
  exit 1
fi
. "$CONFIG"

MIEMBRO="${1:-}"
TIPO="${2:-}"
VERSION="${3:-}"
SUBIR_FLAG=""
SUBIR_ARCHIVO=""

shift 3 2>/dev/null || true
while [ $# -gt 0 ]; do
  case "$1" in
    --subir)
      SUBIR_FLAG="si"
      SUBIR_ARCHIVO="${2:-}"
      shift 2
      ;;
    *)
      echo "Argumento no reconocido: $1"
      exit 1
      ;;
  esac
done

if [ -z "$MIEMBRO" ] || [ -z "$TIPO" ] || [ -z "$VERSION" ]; then
  echo "Uso: compilar-programa.sh <miembro> <batch|cics> <v4|v6|ambas> [--subir <archivo-local>]"
  exit 1
fi

if [ "$TIPO" != "batch" ] && [ "$TIPO" != "cics" ]; then
  echo "El tipo debe ser 'batch' o 'cics'. Recibido: $TIPO"
  exit 1
fi
if [ "$VERSION" != "v4" ] && [ "$VERSION" != "v6" ] && [ "$VERSION" != "ambas" ]; then
  echo "La version debe ser 'v4', 'v6' o 'ambas'. Recibido: $VERSION"
  exit 1
fi

if [ "$TIPO" = "batch" ]; then
  ENTRADA="$BATCHLIB_ENTRADA"
  CMD4="$CMD_BATCH_V4"
  CMD6="$CMD_BATCH_V6"
else
  ENTRADA="$CICSLIB_ENTRADA"
  CMD4="$CMD_CICS_V4"
  CMD6="$CMD_CICS_V6"
fi

ZP="--zosmf-profile ${ZOWE_PROFILE:-zosmf}"

echo "==============================================="
echo " Compilacion real: $MIEMBRO"
echo " Tipo: $TIPO   Version: $VERSION"
echo " Biblioteca de entrada: $ENTRADA"
echo "==============================================="
echo ""
echo "ADVERTENCIA: este script ESCRIBE un objeto compilado en una"
echo "biblioteca de trabajo compartida y en una LOADLIB. No es de"
echo "solo lectura. Confirmar que se tiene autorizacion del equipo"
echo "antes de continuar."
echo ""

# --- Paso 0: sincronizar el fuente local, si se pidio ---
if [ "$SUBIR_FLAG" = "si" ]; then
  if [ ! -f "$SUBIR_ARCHIVO" ]; then
    echo "No existe el archivo local a subir: $SUBIR_ARCHIVO"
    exit 1
  fi
  echo ">> Subiendo fuente local a $ENTRADA($MIEMBRO)"
  if ! zowe zos-files upload file-to-data-set "$SUBIR_ARCHIVO" "$ENTRADA($MIEMBRO)" $ZP; then
    echo "   FALLO al subir. Verificar permisos de escritura sobre $ENTRADA"
    exit 1
  fi
  echo "   ok: el fuente en el mainframe ahora coincide con el clon local"
  echo ""
else
  echo "AVISO: no se uso --subir. Se va a compilar la version que YA"
  echo "esta en $ENTRADA($MIEMBRO) en el mainframe, que puede NO ser"
  echo "la misma que el clon local que el agente analizo estaticamente."
  echo "Si hay dudas, verificar antes de continuar o repetir con --subir."
  echo ""
fi

# --- Envia el comando TSO y captura el JOBID ---
compilar_una_version() {
  cmd="$1"
  etiqueta="$2"

  echo ">> Enviando: $cmd '$ENTRADA($MIEMBRO)'  ($etiqueta)"

  respuesta="$(zowe zos-tso issue command "$cmd '$ENTRADA($MIEMBRO)'" $ZP 2>&1)"
  jobid="$(echo "$respuesta" | tr -d '\r' | grep -Eo 'JOB[0-9]+' | head -1)"

  if [ -z "$jobid" ]; then
    echo "   FALLO: no se encontro un JOBID en la respuesta del comando TSO."
    echo "   Respuesta completa:"
    echo "$respuesta" | sed 's/^/     /'
    echo ""
    echo "   Verificar a mano: puede ser un mensaje de error del CLIST"
    echo "   (nombre de miembro que no cumple estandares, o similar)."
    return 1
  fi

  echo "   job $jobid enviado. Esperando a que termine..."

  intentos=0
  max_intentos=$(( ${TIMEOUT_JOB:-300} / 5 ))
  while [ $intentos -lt $max_intentos ]; do
    estado="$(zowe zos-jobs list jobs --job-id "$jobid" $ZP 2>/dev/null | grep -i "status" || true)"
    if echo "$estado" | grep -qi "OUTPUT"; then
      break
    fi
    sleep 5
    intentos=$((intentos + 1))
  done

  echo "   descargando salida"
  dir_job="entradas/listados/${MIEMBRO}_${etiqueta}"
  rm -rf "$dir_job"
  mkdir -p "$dir_job"
  if ! zowe zos-jobs download output "$jobid" --directory "$dir_job" $ZP >/dev/null 2>&1; then
    echo "   FALLO al descargar la salida del job $jobid"
    return 1
  fi

  lst="$(find "$dir_job" -type f -iname '*SYSPRINT*' | head -1)"
  [ -z "$lst" ] && lst="$(find "$dir_job" -type f | head -1)"

  if [ -n "$lst" ]; then
    destino="entradas/listados/${MIEMBRO}_${etiqueta}.lst"
    cp "$lst" "$destino"
    echo "   listado -> $destino"
    echo ""
    echo "   -- Analisis del listado --"
    python3 scripts/zowe/parse-listado.py "$destino"
    echo ""
  else
    echo "   ADVERTENCIA: no se identifico el SYSPRINT en $dir_job"
    return 1
  fi
  return 0
}

ok=0
if [ "$VERSION" = "v4" ] || [ "$VERSION" = "ambas" ]; then
  compilar_una_version "$CMD4" "v4" && ok=$((ok + 1))
fi
if [ "$VERSION" = "v6" ] || [ "$VERSION" = "ambas" ]; then
  compilar_una_version "$CMD6" "v6" && ok=$((ok + 1))
fi

echo "==============================================="
if [ "$VERSION" = "ambas" ] && [ "$ok" -eq 2 ]; then
  echo " Las dos compilaciones estan en:"
  echo "   entradas/listados/${MIEMBRO}_v4.lst"
  echo "   entradas/listados/${MIEMBRO}_v6.lst"
  echo ""
  echo " Comparar el bloque 'Options in effect' de ambas es evidencia"
  echo " empirica directa para la familia MIG (Paso 4b), sin necesitar"
  echo " el JCL historico de origen."
fi
echo " Compilaciones completadas: $ok"
echo "==============================================="
