# Configuración real del entorno

Datos verificados directamente sobre el sistema **AVDE (Desarrollo)** de Banco AV Villas.

> Este archivo lo lee el agente `cobol-rules-validator`. Reemplaza al antiguo `sondas/RESULTADOS.md`: casi todo lo que las sondas iban a averiguar ya está aquí, obtenido del spool de una compilación real y del archivo de opciones de la instalación.

Última verificación: agosto de 2026, job `JOB57447`.

---

## 1. Compilador

| Dato | Valor | Origen |
|---|---|---|
| Versión | **IBM Enterprise COBOL 6.4** | `STEPLIB DSNAME=IGY.V6R4M0.SIGYCOMP` |
| Nivel de servicio | `P240621` | Encabezado del listado |
| Versión de origen | Enterprise COBOL V4.2 | Migración en curso |

> **Nota sobre la nomenclatura.** Las bibliotecas se llaman `AV62` y los comandos `C62*`, pero el compilador real es **6.4**. El `06.02.00` que aparece en el encabezado del procedimiento es la versión del **procedimiento JCL** `K62BATD`, no del compilador. El catálogo de reglas está correctamente construido sobre 6.4.

---

## 2. Opciones del compilador

Las opciones **no van en el JCL**. El paso de compilación usa `PARM='OPTFILE'`, lo que significa que se leen del archivo apuntado por el DD `SYSOPTF`:

```
SYS1.AVDE230.ALLPROGS.PARMLIB(CBLO62BD)
```

Existe además un juego alternativo, `CBLO62BZ`, que aparece comentado en el procedimiento. Sin analizar.

### Contenido de `CBLO62BD` (completo, 6 líneas)

```
APOST,DYNAM,LIST,FASTSRT,RMODE(ANY),NOSEQ,XREF,NUMPROC(NOPFD),MAP,
SSRANGE,OPTIMIZE(0),TEST(DWARF,NOEJPD,SOURCE,SEPARATE(DSNAME)),
ARCH(12),DIAGTRUNC,INITCHECK(STRICT),NOOFFSET,
NUMCHECK(ZON(ALPHNUM,STRICTREDEF),PAC,BIN(TRUNCBIN),ABD),
INVDATA(NOFORCENUMCMP,NOCLEANSIGN),
COPYRIGHT('Banco AVVillas Colombia')
```

Verificado completo. **No incluye `RULES` ni `PARMCHECK`.**

### Opciones en efecto (del listado de compilación)

Las que importan para el catálogo:

| Opción | Valor efectivo | Lectura |
|---|---|---|
| `INITCHECK` | `STRICT` | Familia INIT **activa**, modo estricto |
| `NUMCHECK` | `ZON(ALPHNUM,STRICT),PAC,BIN(TRUNCBIN),ABD` | Verificación numérica activa, **abendea** al detectar |
| `SSRANGE` | `NOZLEN,ABD` | Rangos verificados, **abendea** |
| `DIAGTRUNC` | activo | Truncamientos diagnosticados |
| `TRUNC` | `STD` | Regla `NUM-06` aplicable |
| `RULES` | **`NORULES`** | **Desviación confirmada.** Regla `OPT-02` |
| `PARMCHECK` | **`NOPARMCHECK`** | **Desviación confirmada.** Regla `OPT-03` |
| `OPTIMIZE` | `0` | Fase 1 |
| `INVDATA` | `NOFORCENUMCMP,NOCLEANSIGN` | Sin tolerancia añadida |
| `NUMPROC` | `NOPFD` | Sin suposición de signos preferidos |
| `ARITH` | `EXTEND` | **Viene de una sentencia `CBL` del fuente** |
| `CODEPAGE` | `1140` | Página de código del sitio |
| `ARCH` / `TUNE` | `12` / `12` | Nivel de hardware |
| `DATA` / `RENT` / `RMODE` | `31` / `RENT` / `ANY` | Residencia sobre la línea |
| `STGOPT` | `NOSTGOPT` | Sin optimización de almacenamiento |
| `MAP` / `XREF` / `SOURCE` | `HEX` / `FULL` / `DEC` | Listado completo disponible |

### Confirmado: las sentencias `CBL` del fuente sí se aplican

En el listado del job `JOB57447`:

```
Invocation parameters:
   OPTFILE
PROCESS(CBL) statements:
   CBL ARITH(EXTEND)
Options from SYSOPTF:
   APOST,DYNAM,LIST,...
```

El programa traía `CBL ARITH(EXTEND)` en el fuente y quedó en las opciones en efecto, pese a no estar en `SYSOPTF`. **Sí es posible activar verificaciones desde el fuente** en copias de trabajo.

Recordatorio: nunca dejar una sentencia `CBL` con verificaciones en un fuente que va a promoción.

### Punto abierto: `STRICTREDEF` vs `STRICT`

`SYSOPTF` especifica `NUMCHECK(ZON(ALPHNUM,STRICTREDEF),...)` pero las opciones en efecto muestran `ZON(ALPHNUM,STRICT)`.

Puede ser normalización del nombre al listar, o que la subopción no se esté aplicando. **De esto depende si la verificación numérica alcanza los campos `REDEFINES`**, que es el corazón de la regla `RDF-02`.

Verificar contra el Programming Guide 6.4, opción `NUMCHECK`. Mientras no se resuelva, `RDF-02` mantiene severidad `CRITICO` en ambas fases.

### Página de código

`CODEPAGE(1140)`. Usarla al bajar cualquier archivo del mainframe para que los acentos de los comentarios no se corrompan.

---

## 2a. Los ocho juegos de opciones

`SYS1.AVDE230.ALLPROGS.PARMLIB` contiene varios juegos. La compilación batch de desarrollo usa `CBLO62BD`; los demás corresponden a otros tipos de compilación o entornos. **La correspondencia exacta miembro/entorno está sin confirmar** y conviene preguntarla.

| Miembro | INITCHECK | NUMCHECK | DIAGTRUNC | SSRANGE | OPT | TRUNC | Datos inválidos |
|---|---|---|---|---|---|---|---|
| `CBLO62BD` | STRICT | **ABD** | sí | sí | 0 | STD | `INVDATA(NOFORCENUMCMP,NOCLEANSIGN)` |
| `CBLO62BZ` | STRICT | **MSG** | sí | sí | 0 | STD | `INVDATA(NOFORCENUMCMP,CLEANSIGN)` |
| `CBLO62F$` | STRICT | MSG | sí | sí | 0 | STD | `INVDATA(...,CLEANSIGN)` + `MDECK(COMPILE)` |
| `CBLO62FR` | STRICT | MSG | sí | sí | 0 | STD | `INVDATA(...,NOCLEANSIGN)` + `MDECK(COMPILE)` |
| `CBLO62BB` | **no** | **no** | **no** | sí | 0 | BIN | `ZONEDATA(NOPFD)` |
| `CBLO62CC` | **no** | **no** | **no** | sí | 0 | BIN | `ZONEDATA(NOPFD)` |
| `CBLO62CT` | STRICT | **no** | **no** | sí | 0 | BIN | `INVDATA(...,CLEANSIGN)` |
| `CBLO62IK` | sin subopción | **no** | sí | sí | **1** | STD | `ZONEDATA(NOPFD)` |

Ninguno de los ocho incluye `RULES` ni `PARMCHECK`.

### Consecuencias para el catálogo

**Cuatro juegos compilan sin `NUMCHECK`.** En `BB`, `CC`, `CT` e `IK` no hay verificación numérica en ejecución. Para los programas compilados con esos juegos, las reglas `RDF-01`, `RDF-02`, `NUM-02` y `NUM-05` son **silenciosas incluso en fase 1**: no hay abend ni mensaje que avise. La severidad de fase 1 sube a `CRITICO` para esos casos.

`CC` y `CT` incluyen `NODYNAM` y `DATA(31)`, propios de compilación CICS. Si se confirma, significa que **los programas CICS no tienen la red de seguridad que sí tienen los batch**.

**Convivencia de `ZONEDATA` e `INVDATA`.** `BB`, `CC` e `IK` usan `ZONEDATA(NOPFD)`; los demás usan `INVDATA`. IBM reemplazó `ZONEDATA` por `INVDATA` precisamente en esta migración. El tratamiento de datos inválidos no es consistente entre tipos de compilación: un mismo defecto puede comportarse distinto según el juego usado. Ver regla `NUM-03`.

**`ABD` contra `MSG`.** `BD` abendea al detectar dato inválido; `BZ` solo emite mensaje y continúa. Existe por tanto una variante menos agresiva ya preparada. Útil cuando el equipo necesite inventariar todos los datos inválidos de una corrida en lugar de parar en el primero.

**`CLEANSIGN` difiere entre juegos del mismo tipo.** `BD` tiene `NOCLEANSIGN` y `BZ` tiene `CLEANSIGN`. Afecta cómo se tratan los signos inválidos. Sin confirmar por qué existen ambos.

**`TRUNC(BIN)` en `BB`, `CC` y `CT`** frente a `TRUNC(STD)` en el resto. La regla `NUM-06` aplica en ambos casos pero con comportamiento distinto.

**`CBLO62IK` es el único con `OPTIMIZE(1)` y `NOTEST`.** Perfil de entorno superior. Es el que más se acerca a la fase 2 de la estrategia, y no tiene `NUMCHECK`.

---

## 2b. Desviaciones frente al estándar interno

La estrategia de la Gerencia de Desarrollo (documento *Migración COBOL V4 a V6*, febrero 2025) pide para la fase 1:

| Pide | Estado real | Regla |
|---|---|---|
| `SSRANGE` | Activo | — |
| `NUMCHECK` | Activo | — |
| `PARMCHECK` | **`NOPARMCHECK`** | `OPT-03` |
| `OPT(0)` | Activo | — |
| `DIAGTRUNC` siempre | Activo | — |
| `RULES(NOLAXPERF,NOENDPERIOD,NOEVENPACK,NOSLACKBYTES)` | **`NORULES`** | `OPT-02` |

Dos desviaciones confirmadas. No son recomendaciones externas: son incumplimiento de un estándar propio del banco, y como tales pesan ante el GATE.

**Consecuencias concretas:**

Sin `RULES(NOLAXREDEF)` no se reportan las longitudes desiguales de `REDEFINES` a nivel 01, que es exactamente el caso de los copybooks.

Sin `PARMCHECK` no hay detección en ejecución del desajuste de parámetros en `CALL`, que es la regla `MIG-06` y uno de los cuatro problemas que el propio documento del banco enumera.

---

## 3. Mecanismo de compilación

No se compila con JCL propio. Se invoca un comando TSO que arma y somete el trabajo.

### Comandos disponibles

| Versión 4 | Versión 6 | Compila | Destino |
|---|---|---|---|
| `CATCICSD` | `C62CICSD` | CICS | `DESA.AV62.LOADLIB` |
| `CATBATD` | `C62BATD` | Batch | `PROD.AV62.LOADLIB.DESA` |
| `CATSOUD` | `C62SOUD` | Fuentes | `DESA.AV00.COPYLIB` |
| `CATBAT61` | `C62BAT61` | Órdenes de proceso | `DESA.AV63.LOADLIB` |
| `CATSOU61` | `C62SOU61` | Órdenes de proceso | `DESA.AV63.SOURCLIB` |

Los CLIST viven en `AVDE.SIST.CMDPROC.COB62`. El procedimiento JCL `K62BATD` está en una PROCLIB del sistema, solo lectura.

Uso:

```
C62BATD 'DESA.AV00.BATCHLIB(PROGRAMA)'
```

### Restricción de nomenclatura

El CLIST valida el nombre del miembro antes de compilar. **El tercer carácter** debe estar en la lista permitida:

| Comando | Tercer carácter admitido |
|---|---|
| `C62BATD` (batch) | `I`, `B`, `C`, `S`, o dígito `0`-`9` |
| `C62CICSD` (CICS) | `O`, `K`, `L` |

Si no cumple, escribe `*** EL NOMBRE DEL OBJETO NO CUMPLE ESTANDARES ***` y termina con código 5.

### Flujo de bibliotecas

```
DESA.AV00.BATCHLIB  ──IEBCOPY──▶  DESA.AV01.BATCHLIB  ──compila──▶  LOADLIB
```

El CLIST copia el fuente desde la biblioteca de entrada hacia la de trabajo antes de compilar. **No lee bibliotecas personales.**

---

## 4. Resolución de copybooks

Orden real del `SYSLIB` en la compilación. Es el que debe replicarse en `zapp.yaml`:

```
1. DESA.AV01.BATCHLIB     el fuente y sus vecinos
2. DESA.AV01.COPYLIB      copybooks de desarrollo
3. PROD.AV00.COPYLIB      copybooks de producción
```

El orden importa: si un copybook existe en las dos bibliotecas, gana el de desarrollo.

---

## 5. Estrategia oficial del banco

Del documento *Migración COBOL V4 a V6*, Gerencia de Desarrollo, febrero de 2025. Define dos fases:

| Fase | Opciones | Propósito |
|---|---|---|
| **1 — Unitaria** | `SSRANGE`, `NUMCHECK`, `PARMCHECK`, `OPT(0)` | Encontrar datos y parámetros inválidos |
| **2 — Calidad y producción** | `NOSSRANGE`, `NONUMCHECK`, `NOPARMCHECK`, `OPT(2)` + `INITCHECK` | Rendimiento |

La configuración actual de `CBLO62BD` corresponde a la **fase 1**.

> **Esto define el valor del agente.** En fase 1 las verificaciones en ejecución atrapan mucho de forma ruidosa. En fase 2 esa red desaparece: lo que no se encontró antes, ya no avisa. El agente cubre lo que la verificación en ejecución nunca alcanza — los caminos que los datos de prueba no recorren — y lo hace antes de compilar.

También recomienda `DIAGTRUNC` siempre y `RULES` con `NOLAXPERF`, `NOENDPERIOD`, `NOEVENPACK` y `NOSLACKBYTES`.

### Problemas conocidos que el banco documenta

Coinciden con las familias del catálogo:

| Problema documentado | Familia |
|---|---|
| Datos inválidos en numéricos `USAGE DISPLAY` | `NUM`, `RDF` |
| Discrepancia de tamaño en parámetros | `MIG-06` |
| `TRUNC(OPT)` o `TRUNC(STD)` con binarios sobrepoblados | `NUM-06` |
| Datos usados antes de recibir valor | `INIT` |

El documento incluye un caso real del banco: una variable `PIC 9(16) COMP-3` que en ejecución trae `X'0404040404040404'`, donde `IF IS NOT NUMERIC` resulta falso en versión 6 y deja pasar una excepción sin controlar. Es la regla `NUM-05`.

---

## 6. Pendientes de verificación

| Qué | Dónde | Por qué importa | Estado |
|---|---|---|---|
| Resto de `CBLO62BD` | PARMLIB | Confirmar `RULES` y `PARMCHECK` | **Cerrado.** Ninguna de las dos está |
| `RULES` presente | Opciones en efecto | Regla `OPT-02` | **Cerrado.** `NORULES` confirmado |
| `PARMCHECK` presente | Opciones en efecto | Regla `OPT-03` | **Cerrado.** `NOPARMCHECK` confirmado |
| Sentencias `CBL` aceptadas | Listado | Si se pueden activar verificaciones | **Cerrado.** Sí se aplican |
| `STRICTREDEF` vs `STRICT` | Programming Guide 6.4, opción `NUMCHECK` | Si la verificación alcanza campos `REDEFINES` | **Abierto** |
| Diferencia con `CBLO62BZ` | Mismo PARMLIB | Juego alternativo preparado | **Cerrado.** `MSG` en vez de `ABD`, y `CLEANSIGN` |
| Opciones de CICS | `SYSOPTF` del procedimiento `K62CICSD` | Pueden diferir de las de batch | **Parcial.** `CBLO62CC` y `CBLO62CT` parecen serlo: sin `NUMCHECK` ni `DIAGTRUNC`. Confirmar la correspondencia |
| Correspondencia miembro / entorno | Preguntar a la Gerencia de Desarrollo | Determina qué severidad aplica a cada programa | Abierto |
| Por qué conviven `ZONEDATA` e `INVDATA` | Gerencia de Desarrollo | Tratamiento inconsistente de datos inválidos | Abierto |
| Opciones de fase 2 | Preguntar a la Gerencia de Desarrollo | Es donde desaparece la red de seguridad | Abierto |

---

## 7. Qué ya no hace falta

El kit de sondas se redujo. Estas quedaron sin objeto porque este archivo responde lo que iban a averiguar:

| Sonda | Reemplazada por |
|---|---|
| SONDA01 — override de opciones | Confirmado en el listado: el programa `KLB113` trae `CBL ARITH(EXTEND)` y la opción quedó en efecto |
| SONDA02, SONDA03, SONDA03B | Solo aplicaban para calibrar `INITCHECK`, que está confirmado en `STRICT` |
| SONDA05 — línea base | Sección 2 de este archivo |

Sigue vigente **`ZZB04`**, y con más razón que antes:

- La discrepancia `STRICTREDEF` / `STRICT` sigue abierta. La sonda responde empíricamente si la verificación alcanza los campos redefinidos: si abendea, sí; si llega al `DISPLAY`, no.
- Cuatro juegos de opciones no tienen `NUMCHECK` en absoluto. Compilar la sonda con el juego de CICS demuestra que ahí el defecto pasa en silencio, que es la evidencia más contundente para el GATE.

Ver `sondas/README.md`.
